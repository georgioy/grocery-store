

<head>
<meta charset="utf-8">
<title>Users</title>
<!-- CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/w3.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link href="css/datatables.min.css" rel="stylesheet">

<!-- jquery-lib -->
<script language="javascript" src="js/jquery.min.js"></script>

</head>

<body>
  <!-- NavBar -->
  <?php include 'navBar.php';?> 
<div class="container">
  <h2>Users <input style="font-size:26px;padding-left:33px;background: url(img/search.png) no-repeat scroll 7px 7px;" type="text" id="search"></h2>
  <br>
  <!-- Add User -->
  <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#newUser">Add User</button> 
  <br><br>      
  
  <table id="" class="table table-striped table-bordered table-sm" cellspacing="0"  width="100%"
  >
    <thead>
      <tr>
        <th class="th-sm">Email</th>
        <th class="th-sm">Username</th>
        <th class="th-sm">Type</th>
        <th class="Deleteth">Delete</th>
        <th class="Editth">Edit</th>
      </tr>
    </thead>
    
    <tbody  id="myTable" class="Table tbody" >
      
    </tbody>
  </table>
</div>
<!-- add user Modal -->
  <div class="modal" id="newUser" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Adding new User</h4>
        </div>
        <div method="get" class="modal-body">
          <table>
            <thead>
              <tr>
                <th>Email</th>
                <th>Username</th>
                <th>Password</th>
                <th><label for="type">Choose a type:</label></th>
              </tr>
            </thead>
            <tr>
              <th><input name="email" value = "" type="email" id="email"/></th>
              <th><input name="uname" value = "" type="text" id="uname"/></th>
              <th><input name="pwd" value = "" type="password" id="pwd"/></th>
              <th>
                  <select name="type" id="type">
                   <option value="Admin">Admin</option> <option value="User">User</option></select></th>
              <!-- <th><input name="type" value = "" type="text" id="type"/></th> -->
            </tr>
          </table>
        </div>
        <div class="modal-footer">
          <button   name="add" value="add" type="button" class="btn btn-default" id="add">Add</button>
          <button type="button" class="btn btn-default" id="close" data-dismiss="modal">Cancel</button>
        </div>
      </div>
      
    </div>
  </div>


  <!-- Scripts -->
<script language="javascript" src="js/users-admin.js"></script>
<script type="text/javascript" src="js/datatables.min.js"></script>
<script language="javascript" src="js/bootsrap.min.js"></script>


</body>
</html>
