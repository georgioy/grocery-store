$(document).ready(function(){

$("#search").keyup(function(){
	str= $(this).val();
	getUsersSearch(str);
});
getUsers();

	function getUsersSearch(val) 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_users.php",
      data:({op:8,srh:val}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          populateUsers(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }
  var globalID=-1;
  function populateUsers(data)
  {
    if(data.length>0){
      
      $("#myTable").empty();
      $.each(data, function(index, row){
        globalID=row.u_id;
        var
         usr="<tr>";
        usr+="<td id='tdemail'>"+row.u_email+"</td>"
        usr+="<td id='tduname'>"+row.u_uname+"</td>"
        usr+="<td id='tdtype' ><div style='text-align: center;'><img id='tdtypeImg' src='img/"+getImage(row.u_type)+"'></div></td>"
        usr+="<td><input type='button' class='btn btn-default'name='"+row.u_id+"' value='X' id='deletebtn'></td>"
        usr+=" <td><input id='btn-edit'  type='button' class='btn btn-primary editbtn' value='Edit'></td>"
        usr+="</tr>"
        $("#myTable").append(usr);
      });
    }
  }

  function getUsers() 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_users.php",
      data:({op:0}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          populateUsers(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }
  var globalID=-1;
  function populateUsers(data)
  {
    if(data.length>0){
      
      $("#myTable").empty();
      $.each(data, function(index, row){
        globalID=row.u_id;
        var
         usr="<tr>";
        usr+="<td id='tdemail'>"+row.u_email+"</td>"
        usr+="<td id='tduname'>"+row.u_uname+"</td>"
        usr+="<td id='tdtype' ><div style='text-align: center;'><img id='tdtypeImg' src='img/"+getImage(row.u_type)+"'></div></td>"
        usr+="<td><input type='button' class='btn btn-default'name='"+row.u_id+"' value='X' id='deletebtn'></td>"
        usr+=" <td><input id='btn-edit'  type='button' class='btn btn-primary editbtn' value='Edit'></td>"
        usr+="</tr>"
        $("#myTable").append(usr);
      });
    }
  }
 	function getImage(type)
	{
		return type==1?"Admin":"User";
	}
	//global variables to save the td values for the cancel button in edit mode
	var globalEmail = '';
	var globalUname = '';
	var globaltype = -1;


	//add button in the add user modal
	$("#add").click(function(){
		
		valid=validateFields();
		
		if(valid)
		{
			var email=$("#email").val();
			var uname=$("#uname").val();
			var pwd=$("#pwd").val();
			var type=$("#type").val();
			if(type=="Admin")
			type=1
			else
			type=0
			

			$("#newUser").modal('hide');
			
			addUser(email,uname,pwd,type);
			getUsers();
			resetFields();
		}
		else
		alert("Fill all the rows")
		
	});
	$("#close").click(function(){
		resetFields();
	});

	
	
	//it resets the fields once the modal is closed
	function resetFields()
	{		
		$("#email").val("");
		$("#uname").val("");
		$("#pwd").val("");
	}

	//it validate if any of the fields are empty in the modal 
	function validateFields(){
		
		var resultn = $("#email").val()!="" ?true:false;
		var resultf= $("#uname").val()!="" ?true:false;
		var resulte = $("#pwd").val()!="" ?true:false;
		var resultb = $("#type").val()!="" ?true:false;
		
	
		
		return resultn && resultf && resulte &&resultb;
	}

	function addUser(userEmail,username,password,userType) 
	{  
	$.ajax({
		type:'GET',
		url: "../utilities/ws_users.php",
		data:({op:4,email:userEmail,uname:username,pwd:password,type:userType}),
  
		dataType:'json',
		timeout:5000,
		success: function(data, textStatus, xhr)
		{
		  if(data==-1)
		  alert("data couldn't be loaded");
		  else{
			if(data=="User already exists")
			alert("User already exists");
			else{
				getUsers();
			}
		  //  data=JSON.parse(xhr.responseText);
		 //   populateUsers(data);
		  }
		},
		error:function(xhr,status,errorThrown)
		{
		  alert(status + errorThrown);
		}
  
	});
	}
	

	//alert to make sure that the user want to delete the whole row
	//Delete User row from Table (Admin Side)
	$("body").on("click","#deletebtn", function(){//Delete X Button
		if (confirm("Are you sure you want to delete the user?"))
		var id=$(this).attr("name");
		 id=id.substring(0);
		 deleteUser(id);
	 	$(this).closest("tr").remove();	
			
	});


	function deleteUser(val) 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_users.php",
      data:({op:3,id:val}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
        //  data=JSON.parse(xhr.responseText);
       //   populateUsers(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }

	//editButton
	$("body").on("click", "#btn-edit", function(){
		
		var email = $(this).parents("tr").find("#tdemail").text() ;
		globalEmail = $(this).parents("tr").find("#tdemail").text();

		var uname = $(this).parents("tr").find("#tduname").text();
		globalUname = $(this).parents("tr").find("#tduname").text();

		globaltype = $(this).parents("tr").find("#tid").val();
	
        $(this).parents("tr").find("td:eq(0)").html('<input name="edit_email" value="'+email+'">');
        $(this).parents("tr").find("td:eq(1)").html('<input name="edit_uname" value="'+uname+'">');
		$(this).parents("tr").find("td:eq(2)").html('<select name="edit_type" id="edit_type"><option value="1">Admin</option> <option value="0">User</option></select>');
    
        $(this).parents("tr").find("td:eq(4)").prepend("<button class='btn btn-info btn-xs btn-update'>Update</button><button class='btn btn-warning btn-xs btn-cancel'>Cancel</button>")
		$(this).hide();
		
	});
	
	//updateButton in edit mode
    $("body").on("click", ".btn-update", function(){
		if (confirm("Are you sure you want to modify the user?"))
		var id=$(this).parents("tr").find("#deletebtn").attr("name");//gets the ID of the User from the Delete BUtton name using its #ID
		 	id=id.substring(0);
        var email = $(this).parents("tr").find("input[name='edit_email']").val();
        var uname = $(this).parents("tr").find("input[name='edit_uname']").val();
		var type = $(this).parents("tr").find("select[name='edit_type']").val();
			updateUser(id,email,uname,type);
		globaltype=type;
		if(globaltype==1)
		type="Admin"
		else
		type="User";
        $(this).parents("tr").find("td:eq(0)").text(email);
        $(this).parents("tr").find("td:eq(1)").text(uname);
		$(this).parents("tr").find("td:eq(2)").html('<img id="tdtypeImg" src="img/'+type+'">');

		
		$(this).parents("tr").find("td:eq(4)").prepend("<button id='btn-edit' class='btn btn-primary editbtn'>Edit</button><button class='btn btn-warning btn-xs btn-cancel'>Cancel</button>")
		$(this).parents("tr").find(".btn-update").hide();
		$(this).parents("tr").find(".btn-cancel").hide();
		
	});
	function updateUser(userID,userEmail,username,userType) 
	{  
	$.ajax({
		type:'GET',
		url: "../utilities/ws_users.php",
		data:({op:5,id:userID,email:userEmail,uname:username,type:userType}),
  
		dataType:'json',
		timeout:5000,
		success: function(data, textStatus, xhr)
		{
		  if(data==-1){
			alert("Data Couldn't be Loaded");
		  }
		  else if (data==1){
			getUsers();
		  }
		},
		error:function(xhr,status,errorThrown)
		{
		  alert(status + errorThrown);
		}
  
	});
	}

	//cancelButton in edit mode
	$("body").on("click", ".btn-cancel", function(){
		getUsers(); 
		
	});
   
	
});