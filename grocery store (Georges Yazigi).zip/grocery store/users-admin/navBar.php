<?php
echo '<nav class="w3-bar w3-green">
    <a href="../HomePage/Home-Page.php" class="w3-button w3-bar-item">Home</a>
    <a href="users.php" class="w3-button w3-bar-item">Users</a>
    <a  href="../categories-admin/categories.php" class="w3-button w3-bar-item">Categories</a>
    <a  href="../items-admin/items.php" class="w3-button w3-bar-item">Items</a>
    <a  href="../orders-admin/orders-admin.php" class="w3-button w3-bar-item">Orders</a>
    <a href="../contactUs/ContactUs.php" class="w3-button w3-bar-item">Contact Us</a>
    <a id="logout-bar-item" href="../index.php" class="w3-button w3-bar-item">Logout</a>
  </nav>'
  ?>