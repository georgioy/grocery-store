<?php
echo '<nav class="w3-bar w3-green">
<a href="Home-PageUser.php" class="w3-button w3-bar-item">Home</a>
<a href="../categories-user/categoriesUser.php" class="w3-button w3-bar-item">Categories</a>
<a href="../contactUs-user/ContactUsUser.php" class="w3-button w3-bar-item">Contact Us</a>
<div id="logout-bar-item"> <a id="basketbtn" href="../basket-user/basketUser.php"
class="w3-button w3-bar-item" ><img src="img/cart-white.png"></a></div>
<a id="logout-bar-item" href="../index.php" class="w3-button w3-bar-item">Logout</a>
</nav>'
?>