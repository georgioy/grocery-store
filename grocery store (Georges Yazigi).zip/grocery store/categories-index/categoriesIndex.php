
<?php
date_default_timezone_set('Asia/Beirut');
$date= date('d-m-y h:i:s');
$location="Categories Index page  opened";
include '../utilities/Utilities.php';
writeToLog($date,$location);
?>
<!DOCTYPE html>
<html>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <head>
        <title>Home Page</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link href="css/datatables.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="../dist/jBox.all.css">
        <link rel="stylesheet" href="css/demo.css">
        <link rel="stylesheet" href="css/playground-avatars.css">
        <link rel="stylesheet" href="css/playground-inception.css">
        <link rel="stylesheet" href="css/playground-login.css">
        <link rel="stylesheet" href="css/w3.css">


  <script src="js/jquery-3.5.0.js"></script>
        
    </head>
        
    <body>
 <!-- NavBar -->
 <?php include 'navBar.php';?> 
 
 

 <div class="w3-row-padding w3-section w3-stretch ">
  <div class="w3-col s4 ">
    <div class="w3-container">
    <table id="" class="w3-table-all w3-hoverable" cellspacing="0" width="100%">
      <thead>
        <tr class="w3-light-grey">
        <th >Categories</th>
        <th ></th>

        </tr>
      </thead>
      <tbody id="catTable" class="Table tbody">

      </tbody>
    </table>
    </div>

  </div>
  <div class="w3-col s4 ">
  <div class="w3-container">
  <table id="" class="w3-table-all w3-hoverable" cellspacing="0" width="100%">
      <thead>
        <tr class="w3-light-grey">
        <th id="catNameTh"></th>
        <th ></th>
        <th ></th>
        </tr>
      </thead>
      <tbody id="itemsTable" class="Table tbody">
        <tr>
            <td style="padding-left:105px;">Select a categorie...</td>
        </tr>
      </tbody>
    </table>
    </div>
  </div>
  <div class="w3-col s4 ">
  <div class="w3-container">
  <table id="" class="" cellspacing="0" width="100%">
      <thead>
        <tr class="w3-light-grey">
        <th id="itemNameTh"></th>
        <th ></th>
        <th ></th>
        <th></th>
        </tr>
      </thead>
      <tbody id="itemTable" class="Table tbody">
        <tr>
            <td style="padding-left:105px;">Select an Item...</td>
        </tr>
      </tbody>
    </table>
    </div>
  </div>
</div>






<div style="display: none" id="signup" >
                    <div>
                    <div id="uname_response" ></div>
                    <input class="textbox" type="text" id="txt_username" name="txt_username" placeholder="Username" />
                    </div>
                    <div>
                    <br>
                    <div id="email_response" ></div>
                    <input class="textbox" type="email" name="email" placeholder="Email" id="txt_email"/>
                    </div>
                    <div>
                    <br>
                    <input class="textbox" type="password" name="Password" placeholder="Password" id="txt_Password"/>
                    </div>
                    <div>
                    <input class="textbox" type="password" name="Password2" placeholder="Confirm Password" id="txt_Password2"/>
                    <div id="password_response" ></div>
                    </div>
                    <br>
                    <button name="register" id="reg_btn" class="inception-modal-button" data-inception-tooltip="Register">Sign Up</button>
                
                  
</div>
<div style="display: none" id="login">
                    <div>               
                    <input class="textbox" type="text" name="uname" placeholder="Username" required id="username">
                   
                    </div>           
                    <div>
                    <br>
                    <input class="textbox" name="upwd" type="password" placeholder="Password" required id="password" >
                    </div>
                    <div>
                    <br>
                    <button type="Button"  value="submit" id="but_submit">Log In</button>
                    </div>
                    <div>
                    <span style="color:#FF0000;"></span>
                    </div>
                    <div>
                    <p>Not Registered?<button class="inception-modal-button" data-inception-tooltip="Create A New Account">Register</button></p>

                    </div>
</div>      









<script src="../dist/jBox.all.js"></script>
  <script src="js/demo.js"></script>
  <script src="js/playground-avatars.js"></script>
  <script src="js/playground-inception.js"></script>
  <script src="js/playground-login.js"></script>

  <script src="js/loginsignup.js"></script>
  <script src="js/categories-index.js"></script>

</body>

    
</html>