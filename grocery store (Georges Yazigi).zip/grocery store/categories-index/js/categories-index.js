$(document).ready(function(){

    getcategories();

	function getcategories() 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_categories.php",
      data:({op:0}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          populateCategories(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }
  function populateCategories(data)
  {
    if(data.length>0){
      $("#catTable").empty();
      $.each(data, function(index, row){
        var
         cat="<tr >";
		 cat+="<td id='tdimg'>"+row.cat_name+"<br><br><div style='text-align: center;'><img id='image' name='"+row.cat_img+"' height=75px width=100px src='../categories-admin/upload/"+row.cat_img+"'></div></td>"
         cat+="<td id='btnitems'><input type='image' name='"+row.cat_name+"' id='appendItems' src='img/next.png' alt='button' width='48' height='48'></td>"
         cat+="</tr>"
        $("#catTable").append(cat);
      });
    }
  }
  $("body").on("click","#appendItems", function(){// ">" Next ImageButton in categories table
  var catName = $(this).parents("tr").find("#appendItems").attr("name") ;
        $(this).parents("div").parents("div").parents("div").find("#catNameTh").html(catName);
        getItems(catName);
});



	function getItems(categorieName) 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_items.php",
      data:({op:4,itemCatName:categorieName}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          populateItems(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }

  function populateItems(data)
  {
    if(data.length>0){
      
      $("#itemsTable").empty();
      $.each(data, function(index, row){
          var x=row.item_price;
          var y=row.item_discount;
          var newPrice;
        var
         itm="<tr >";
         itm+="<td  id='tdimg'>"+row.item_name+"<br><br><div style='text-align: center;'><img id='image' name='"+row.item_img+"' height=75px width=100px src='../items-admin/upload/"+row.item_img+"'></div></td>"
        
         if (y!=0 ) {
            newPrice = x - (x * y / 100);
            itm+="<td  id='tdprice' ><span style='color:#4CAF50; '><b>-</b>"+row.item_discount +"% "+"<br><span style='color:gray; text-decoration:line-through '>LBP "+ row.item_price+"</span><br> LBP "+newPrice+"</td>"
          }
          else
         itm+="<td id='tdprice' ><br><div style=' width: 100px; '><span >LBP "+ row.item_price+"</span></div></td>"
         itm+="<td id='btnitem'><input type='image' name='"+row.item_name+"' id='appendItem' src='img/next.png' alt='button' width='48' height='48'></td>"
		 itm+="</tr>"
        $("#itemsTable").append(itm);
      });
    }
  }

  $("body").on("click","#appendItem", function(){// ">" Next ImageButton in categories table
  var itemName = $(this).parents("tr").find("#appendItem").attr("name") ;
        $(this).parents("div").parents("div").parents("div").find("#itemNameTh").html(itemName);
        getItem(itemName);
});

function getItem(ItemName) 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_items.php",
      data:({op:5,itemName:ItemName}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          populateItem(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }

  function populateItem(data)
  {
    if(data.length>0){
      
      $("#itemTable").empty();
      $.each(data, function(index, row){
          var x=row.item_price;
          var y=row.item_discount;
          var newPrice;
        var
         
         itm="<tr>";
         itm+="<td  id='tdimg'><div style='text-align: center;'><img id='image' name='"+row.item_img+"' height=75px width=100px src='../items-admin/upload/"+row.item_img+"'></div></td>"
         itm+="</tr>"
         itm+="<tr>"
         if (y!=0 ) {
            newPrice = x - (x * y / 100);
            itm+="<td  id='tdprice' ><div style='max-width: 500px; margin: auto;'><br>Price: <span style='color:gray; text-decoration:line-through '>LBP "+ row.item_price+"</span><span style='color:#4CAF50; '> <b>-</b>"+row.item_discount +"%</span> <img height=35px src=img/right.png> "+" LBP "+newPrice+"</div></td>"
          }
          else
         itm+="<td id='tdprice' ><div style='max-width: 500px; margin: auto;'><br>Price: <span >LBP "+ row.item_price+"</span></div></td>"
         itm+="</tr>"
         itm+="<tr>"
         itm+="<td>"+row.item_desc+"</td>"
         itm+="</tr>"
         itm+="<tr>"
         itm+="<td>"
         itm+="<p class='plus-minus'><input type='image' src='img/minus.png' id='minus1' width='20' height='20' class='minus'/><input id='qty1' type='text' value='1' style='width:50px;text-align:center;' class='qty'/><input type='image' id='add1' src='img/plus.png' width='20' height='20' class='add'/></p>"
         itm+="</td>"
         itm+="</tr>"
         itm+="<tr>"
         itm+="<td><p><input class='cart' id='loginfirst' type='button' value='Add to Cart'></input></p></td>"
         itm+="</tr>"
        $("#itemTable").append(itm);
      });
    }
  }
 
  $(function () {
    $("body").on("click",".add", function(){
        var $qty=$(this).closest('p').find('.qty');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal)) {
            $qty.val(currentVal + 1);
        }
    });
    $("body").on("click",".minus", function(){
        var $qty=$(this).closest('p').find('.qty');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal) && currentVal > 0) {
            $qty.val(currentVal - 1);
        }
    });
});
//on add to cart click
$("body").on("click","#loginfirst", function(){
  $("body").find("#logout-bar-item").click();
  new jBox('Notice', {
    attributes: {
      x: 'right',
      y: 'bottom'
    },
    stack: false,
    animation: {
      open: 'tada',
      close: 'zoomIn'
    },
    color: getColor(),
    title: 'You must be logged in to do this!',
    content: 'Login or Register'
  });
});
var colors = ['black','yellow','red'];
var index = 0;
var getColor = function () {
  if (index >= colors.length) {
    index = 0;
  }
  return colors[index++];
};

});