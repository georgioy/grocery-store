<?php
echo '<nav class="w3-bar w3-green">
<a href="../index.php" class="w3-button w3-bar-item">Home</a>
<a href="categoriesIndex.php" class="w3-button w3-bar-item">Categories</a>
<a href="../contactUs-index/ContactUsIndex.php" class="w3-button w3-bar-item">Contact Us</a>
<div id="Login"><button id="logout-bar-item"<a id="Loginbtn" 
class="w3-button w3-bar-item" >Login <img src="img/login.png"></a></button></div>
</nav>'
?>