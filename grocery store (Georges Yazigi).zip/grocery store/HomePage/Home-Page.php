<!-- <?php
session_start();
// include("../utilities/permissions.php");
echo($_SESSION["uName"]);
?> -->
<!DOCTYPE html>
<html>
<?php
 

date_default_timezone_set('Asia/Beirut');
$date= date('d-m-y h:i:s');
$location="Home Page opened";
include '../utilities/Utilities.php';
writeToLog($date,$location);
?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <head>
        <title>Home Page</title>
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <script src="js/Home-Page.js"></script>
        <script src="js/jquery.min.js"></script>
        

        
    </head>
        
    <body>
          <?php include 'navBar.php';?> 
    </body>

    
</html>