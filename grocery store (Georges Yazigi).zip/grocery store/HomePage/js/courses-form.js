$(document).ready(function(){
	
	$("#ok").click(function(){
		
		valid=validateFields();
		
		if(valid)
		{
			Course=$("#Course").val();
			Credits=$("#Credits").val();
			InstructorName=$("#InstructorName").val();

			var row="<tr >";
				row+="<td  id='tdCourse'>"+Course+"</td>";
				row+="<td  id='tdCredits'>"+Credits+"</td>";
				row+="<td  id='tdInstructorName'>"+InstructorName+"</td>";
				row+= "<td>" +
				"<button onclick='deleteRow(this)'' type='button' id='deletebtn' class='btn btn-default'>" +
				"X" +
				"</button>" +
				"</td>";
				row+="<td>"+ 
				"<button id='btn-edit'  type='button' class='btn btn-primary editbtn'>"+
				"Edit"+
				"</button>"+
				"</td>";
				row+="</tr>";


			$("#tblcourses").append(row);

			$("#newCourse").modal('hide');
			
			resetFields();
		}
		else
		alert("Fill all the rows")
	});

	
	$(document).ready(function(){
		$("#myInput").on("keyup", function() {
		  var value = $(this).val().toLowerCase();
		  $("#myTable tr").filter(function() {
			$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
		  });
		});
	  });

	function resetFields()
	{		
		$("#Course").val("");
		$("#Credits").val("");
		$("#InstructorName").val("");
	}
	
	function validateFields(){
		
		var resultn = $("#Course").val()!="" ?true:false;
		var resultf= $("#Credits").val()!="" ?true:false;
		var resulte = $("#InstructorName").val()!="" ?true:false;
		
	
		
		return resultn && resultf && resulte;
	}
	
	
	

	$("body").on("click","#deletebtn", function(){
		if (confirm("Are you sure you want to delete the row?"))
            $(this).closest("tr").remove();
	});

	
	var globalCourse = '';
	var globalNuberOfCredits = '';
	var GlobalInstructorName = '';
	$("body").on("click", "#btn-edit", function(){
		
		var course = $(this).parents("tr").find("#tdCourse").text() ;
		globalCourse = $(this).parents("tr").find("#tdCourse").text();

		var credits = $(this).parents("tr").find("#tdCredits").text();
		globalNuberOfCredits = $(this).parents("tr").find("#tdCredits").text();

		var instructorName = $(this).parents("tr").find("#tdInstructorName").text();
		GlobalInstructorName = $(this).parents("tr").find("#tdInstructorName").text();
    
        $(this).parents("tr").find("td:eq(0)").html('<input name="edit_course" value="'+course+'">');
        $(this).parents("tr").find("td:eq(1)").html('<input name="edit_credits" value="'+credits+'">');
        $(this).parents("tr").find("td:eq(2)").html('<input name="edit_instructorName" value="'+instructorName+'">');
    
        $(this).parents("tr").find("td:eq(4)").prepend("<button class='btn btn-info btn-xs btn-update'>Update</button><button class='btn btn-warning btn-xs btn-cancel'>Cancel</button>")
		$(this).hide();
		
	});
	

    $("body").on("click", ".btn-update", function(){
        var course = $(this).parents("tr").find("input[name='edit_course']").val();
        var credits = $(this).parents("tr").find("input[name='edit_credits']").val();
        var instructorName = $(this).parents("tr").find("input[name='edit_instructorName']").val();
    
        $(this).parents("tr").find("td:eq(0)").text(course);
        $(this).parents("tr").find("td:eq(1)").text(credits);
        $(this).parents("tr").find("td:eq(2)").text(instructorName);

		
		$(this).parents("tr").find("td:eq(4)").prepend("<button id='btn-edit' class='btn btn-primary editbtn'>Edit</button><button class='btn btn-warning btn-xs btn-cancel'>Cancel</button>")
		$(this).parents("tr").find(".btn-update").hide();
		$(this).parents("tr").find(".btn-cancel").hide();
		

		
	});
	$("body").on("click", ".btn-cancel", function(){
		
		$(this).parents("tr").find("input[name='edit_course']").hide();
		$(this).parents("tr").find("input[name='edit_credits']").hide();
		$(this).parents("tr").find("input[name='edit_instructorName']").hide();

		$(this).parents("tr").find("td:eq(0)").text(globalCourse);
        $(this).parents("tr").find("td:eq(1)").text(globalNuberOfCredits);
        $(this).parents("tr").find("td:eq(2)").text(GlobalInstructorName);

    
        $(this).parents("tr").find(".btn-update").hide();
		$(this).parents("tr").find(".btn-cancel").hide();
		$(this).parents("tr").find("td:eq(4)").prepend("<button id='btn-edit' class='btn btn-primary editbtn'>Edit</button>")
	});
   
	
});