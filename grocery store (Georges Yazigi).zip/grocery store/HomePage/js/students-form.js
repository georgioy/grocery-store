$(document).ready(function(){

	// dtLibrary for the table
	$('#dtBasicExample').DataTable();
	$('.dataTables_length').addClass('bs-select');

	//Modal submit(ok) button on click ;it adds a new row
	$("#ok").click(function(){
		
		valid=validateFields();
		
		if(valid)
		{
			name=$("#name").val();
			family=$("#family").val();
			email=$("#email").val();

			var row="<tr >";
				row+="<td  id='tdname'>"+name+"</td>";
				row+="<td  id='tdfamily'>"+family+"</td>";
				row+="<td  id='tdemail'>"+email+"</td>";
				row+= "<td>" +
				"<button onclick='deleteRow(this)'' type='button' id='deletebtn' class='btn btn-default'>" +
				"X" +
				"</button>" +
				"</td>";
				row+="<td>"+ 
				"<button id='btn-edit'  type='button' class='btn btn-primary editbtn'>"+
				"Edit"+
				"</button>"+
				"</td>";
				row+="</tr>";


			$("#dtBasicExample").append(row);

			$("#newStudent").modal('hide');
			
			resetFields();
		}
		else
		alert("Fill all the rows")
	});
	$("#close").click(function(){
		resetFields();
	});

	
	
	//it resets the fields once the modal is closed
	function resetFields()
	{		
		$("#name").val("");
		$("#family").val("");
		$("#email").val("");
	}

	//it validate if any of the fields are empty in the modal 
	function validateFields(){
		
		var resultn = $("#name").val()!="" ?true:false;
		var resultf= $("#family").val()!="" ?true:false;
		var resulte = $("#email").val()!="" ?true:false;
		
	
		
		return resultn && resultf && resulte;
	}

	//alert to make sure that the user want to delte the row
	$("body").on("click","#deletebtn", function(){
		if (confirm("Are you sure you want to delete the row?"))
            $(this).closest("tr").remove();
	});

	//global variables to save the td values for the cancel button in edit mode
	var globalName = '';
	var globalFamily = '';
	var globalEmail = '';

	//editButton
	$("body").on("click", "#btn-edit", function(){
		
		var name = $(this).parents("tr").find("#tdname").text() ;
		globalName = $(this).parents("tr").find("#tdname").text();

		var family = $(this).parents("tr").find("#tdfamily").text();
		globalFamily = $(this).parents("tr").find("#tdfamily").text();

		var email = $(this).parents("tr").find("#tdemail").text();
		globalEmail = $(this).parents("tr").find("#tdemail").text();
    
        $(this).parents("tr").find("td:eq(0)").html('<input name="edit_name" value="'+name+'">');
        $(this).parents("tr").find("td:eq(1)").html('<input name="edit_family" value="'+family+'">');
        $(this).parents("tr").find("td:eq(2)").html('<input name="edit_email" value="'+email+'">');
    
        $(this).parents("tr").find("td:eq(4)").prepend("<button class='btn btn-info btn-xs btn-update'>Update</button><button class='btn btn-warning btn-xs btn-cancel'>Cancel</button>")
		$(this).hide();
		
	});
	
	//updateButton in edit mode
    $("body").on("click", ".btn-update", function(){
        var name = $(this).parents("tr").find("input[name='edit_name']").val();
        var family = $(this).parents("tr").find("input[name='edit_family']").val();
        var email = $(this).parents("tr").find("input[name='edit_email']").val();
    
        $(this).parents("tr").find("td:eq(0)").text(name);
        $(this).parents("tr").find("td:eq(1)").text(family);
        $(this).parents("tr").find("td:eq(2)").text(email);

		
		$(this).parents("tr").find("td:eq(4)").prepend("<button id='btn-edit' class='btn btn-primary editbtn'>Edit</button><button class='btn btn-warning btn-xs btn-cancel'>Cancel</button>")
		$(this).parents("tr").find(".btn-update").hide();
		$(this).parents("tr").find(".btn-cancel").hide();
		

		
	});

	//cancelButton in edit mode
	$("body").on("click", ".btn-cancel", function(){
		
		$(this).parents("tr").find("input[name='edit_name']").hide();
		$(this).parents("tr").find("input[name='edit_family']").hide();
		$(this).parents("tr").find("input[name='edit_email']").hide();

		$(this).parents("tr").find("td:eq(0)").text(globalName);
        $(this).parents("tr").find("td:eq(1)").text(globalFamily);
        $(this).parents("tr").find("td:eq(2)").text(globalEmail);

    
        $(this).parents("tr").find(".btn-update").hide();
		$(this).parents("tr").find(".btn-cancel").hide();
		$(this).parents("tr").find("td:eq(4)").prepend("<button id='btn-edit' class='btn btn-primary editbtn'>Edit</button>")
	});
   
	
});