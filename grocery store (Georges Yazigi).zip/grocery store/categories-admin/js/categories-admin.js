$(document).ready(function(){

	$(document).on('change', '#file', function(){
		var name = document.getElementById("file").files[0].name;
		var form_data = new FormData();
		var ext = name.split('.').pop().toLowerCase();
		if(jQuery.inArray(ext, ['gif','png','jpg','jpeg']) == -1) 
		{
		 alert("Invalid Image File");
		}
		var oFReader = new FileReader();
		oFReader.readAsDataURL(document.getElementById("file").files[0]);
		var f = document.getElementById("file").files[0];
		var fsize = f.size||f.fileSize;
		if(fsize > 2000000)
		{
		 alert("Image File Size is very big");
		}
		else
		{
		 form_data.append("file", document.getElementById('file').files[0]);
		 $.ajax({
		  url:"upload.php",
		  method:"POST",
		  data: form_data,
		  contentType: false,
		  cache: false,
		  processData: false,
		  beforeSend:function(){
		   $('#uploaded_image').html("<label class='text-success'>Image Uploading...</label>");
		  },   
		  success:function(data)
		  {
		   $('#uploaded_image').html(data);
		  }
		 });
		}
	   });





	
	var myModal = $('#addcat').jBox('Modal');
 
myModal.setTitle('Add Categorie').setContent($('#addcategorie'));


	getcategories();
	function getcategories() 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_categories.php",
      data:({op:0}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          populateCategories(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }
  var globalID=-1;
  function populateCategories(data)
  {
    if(data.length>0){
      
      $("#myTable").empty();
      $.each(data, function(index, row){
        globalID=row.cat_id;
        var
         cat="<tr>";
		 cat+="<td id='tdimg'><div style='text-align: center;'><img id='image' name='"+row.cat_img+"' height=75px width=100px src='upload/"+row.cat_img+"'></div></td>"
		 cat+="<td id='tdname'>"+row.cat_name+"</td>"
		 cat+="<td><input type='button' class='btn btn-default'name='"+row.cat_id+"' value='X' id='deletebtn'></td>"
		 cat+=" <td><input id='btn-edit'  type='button' class='btn btn-primary editbtn' value='Edit'></td>"
		 cat+="</tr>"
        $("#myTable").append(cat);
      });
    }
  }
 	
	//global variables to save the td values for the cancel button in edit mode
	var globalimage = '';
	var globalname = '';


	//Modal submit(add) button on click ;it displays the modal to add a new user
	$("#add").click(function(){
	
		valid=validateFields();
		
		if(valid)
		{
			var img=$("#uploadedImage").attr("name");
			var name=$("#name").val();
			
			
			$("#addcategorie").modal('hide');
			
			addCategorie(img,name);
			resetFields();
			getcategories();
			
		}
		else
		alert("Fill all the rows")
		
	});
	

	
	
	//it resets the fields once the modal is closed
	function resetFields()
	{		
		$("#file").val("");
		$("#uploaded_image").html("");
		$("#name").val("");
	}

	//it validate if any of the fields are empty in the modal 
	function validateFields(){
		
		var resulti = $("#file").val()!="" ?true:false;
		var resultn= $("#name").val()!="" ?true:false;
		
		return resulti && resultn ;
	}

	function addCategorie(catImg,catName) 
	{  
	$.ajax({
		type:'GET',
		url: "../utilities/ws_categories.php",
		data:({op:2,img:catImg,name:catName}),
  
		dataType:'json',
		timeout:5000,
		success: function(data, textStatus, xhr)
		{
		  if(data==-1)
		  alert("data couldn't be loaded");
		  else{
			if(data=="categorie already exists")
			alert("categorie already exists");
			else{
				getcategories();
			}
		  //  data=JSON.parse(xhr.responseText);
		 //   populateUsers(data);
		  }
		},
		error:function(xhr,status,errorThrown)
		{
		  alert(status + errorThrown);
		}
  
	});
	}
	

	//alert to make sure that the user want to delete the whole row
	//Delete Categorie row from Table (Admin Side)
	$("body").on("click","#deletebtn", function(){//Delete X Button
		if (confirm("Are you sure you want to delete this Categorie?"))
		var id=$(this).attr("name");
		 id=id.substring(0);
		 deleteCategorie(id);
	 	$(this).closest("tr").remove();	
			
	});


	function deleteCategorie(val) 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_categories.php",
      data:({op:1,id:val}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
        //  data=JSON.parse(xhr.responseText);
       //   populateUsers(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }

	//editButton
	$("body").on("click", "#btn-edit", function(){
		
		var img = $(this).parents("tr").find("#tdimg").find("#image").attr("name") ;
		globalimage = $(this).parents("tr").find("#tdimg").text();

		var name = $(this).parents("tr").find("#tdname").text();
		globalname = $(this).parents("tr").find("#tdname").text();


	
        $(this).parents("tr").find("td:eq(0)").html('<div style="text-align: center;"><img id="image" name="'+img+'" height=75px width=100px src="upload/'+img+'"></div><label for="image">Choose an image:</label><br><input type="file" name="file" id="file" /><br/><span id="uploaded_image"></span>');
        $(this).parents("tr").find("td:eq(1)").html('<input name="edit_name" value="'+name+'">');
    
        $(this).parents("tr").find("td:eq(3)").prepend("<button class='btn btn-info btn-xs btn-update'>Update</button><button class='btn btn-warning btn-xs btn-cancel'>Cancel</button>")
		$(this).hide();
		
	});
	
	//updateButton in edit mode
    $("body").on("click", ".btn-update", function(){
		if (confirm("Are you sure you want to modify the categorie?"))
		var id=$(this).parents("tr").find("#deletebtn").attr("name");//gets the ID of the categorie from the Delete BUtton name using its #ID
			 id=id.substring(0);
			 
		var img = $(this).parents("tr").find("#uploadedImage").attr("name");
		switch (img){
			case undefined:
			var oldimg = $(this).parents("tr").find("#image").attr("name");
			var name = $(this).parents("tr").find("input[name='edit_name']").val();
			updateCategorie(id,oldimg,name);
			break;

			default:
			var name = $(this).parents("tr").find("input[name='edit_name']").val();
			updateCategorie(id,img,name);
		}
		
			
		
			
		
		$(this).parents("tr").find("td:eq(3)").prepend("<button id='btn-edit' class='btn btn-primary editbtn'>Edit</button><button class='btn btn-warning btn-xs btn-cancel'>Cancel</button>")
		$(this).parents("tr").find(".btn-update").hide();
		$(this).parents("tr").find(".btn-cancel").hide();
		
	});
	function updateCategorie(catID,catImg,catName,catDesc) 
	{  
	$.ajax({
		type:'GET',
		url: "../utilities/ws_categories.php",
		data:({op:3,id:catID,img:catImg,name:catName}),
  
		dataType:'json',
		timeout:5000,
		success: function(data, textStatus, xhr)
		{
		  if(data==-1){
			alert("Data Couldn't be Loaded");
		  }
		  else if (data==1){
			getcategories();
		  }
		},
		error:function(xhr,status,errorThrown)
		{
		  alert(status + errorThrown);
		}
  
	});
	}

	//cancelButton in edit mode
	$("body").on("click", ".btn-cancel", function(){
		getcategories(); 
		
	});
   
	
});