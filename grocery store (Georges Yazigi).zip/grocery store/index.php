


<head style="font-family: sans-serif">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LB Grocery Store</title>
<!-- CSS -->
<link rel="stylesheet" href="index/css/bootstrap.min.css">
<link rel="stylesheet" href="index/css/bootstrap.css">
<link href="index/css/datatables.min.css" rel="stylesheet">
<link rel="stylesheet" href="index/css/normalize.css">
<link rel="stylesheet" href="dist/jBox.all.css">
<link rel="stylesheet" href="index/css/demo.css">
<link rel="stylesheet" href="index/css/playground-avatars.css">
<link rel="stylesheet" href="index/css/playground-inception.css">
<link rel="stylesheet" href="index/css/playground-login.css">
<link rel="stylesheet" href="index/css/w3.css">
<link rel="stylesheet" href="index/css/style.css">


<script src="index/js/jquery-3.5.0.js"></script>
<link href="index/css?family=Roboto:400,500" rel="stylesheet">
</head>


<body style="font-family: sans-serif">
 <!-- NavBar -->
 <?php include 'index/navBar.php';?> 






<div style="display: none" id="signup" >
                    <div>
                    <div id="uname_response" ></div>
                    <input class="textbox" type="text" id="txt_username" name="txt_username" placeholder="Username" />
                    </div>
                    <div>
                    <br>
                    <div id="email_response" ></div>
                    <input class="textbox" type="email" name="email" placeholder="Email" id="txt_email"/>
                    </div>
                    <div>
                    <br>
                    <input class="textbox" type="password" name="Password" placeholder="Password" id="txt_Password"/>
                    </div>
                    <div>
                    <input class="textbox" type="password" name="Password2" placeholder="Confirm Password" id="txt_Password2"/>
                    <div id="password_response" ></div>
                    </div>
                    <br>
                    <button name="register" id="reg_btn" class="inception-modal-button" data-inception-tooltip="Register">Sign Up</button>
                
                  
</div>
<div style="display: none" id="login">
                    <div>               
                    <input class="textbox" type="text" name="uname" placeholder="Username" required id="username">
                   
                    </div>           
                    <div>
                    <br>
                    <input class="textbox" name="upwd" type="password" placeholder="Password" required id="password" >
                    </div>
                    <div>
                    <br>
                    <button type="Button"  value="submit" id="but_submit">Log In</button>
                    </div>
                    <div>
                    <span style="color:#FF0000;"></span>
                    </div>
                    <div>
                    <p>Not Registered?<button class="inception-modal-button" data-inception-tooltip="Create A New Account">Register</button></p>

                    </div>
</div>      


<!-- jquery-lib -->
<script language="javascript" src="index/js/jquery.min.js"></script>
<script src="dist/jBox.all.js"></script>
<script src="index/js/demo.js"></script>
<script src="index/js/playground-avatars.js"></script>
<script src="index/js/playground-inception.js"></script>
<script src="index/js/playground-login.js"></script>

<script src="index/js/index.js"></script>
<script src="index/js/loginsignup.js"></script>

</body>
</html>