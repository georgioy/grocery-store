<?php
date_default_timezone_set('Asia/Beirut');
$date= date('d-m-y h:i:s');
$location="Contact Us page  opened";
include '../utilities/Utilities.php';
writeToLog($date,$location);
?>
<!DOCTYPE html>
<html>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <head>
        <title>Home Page</title>
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="css/style.css">
        <script src="js/Home-Page.js"></script>
        <script src="js/jquery.min.js"></script>

        
    </head>
        
    <body>
 <!-- NavBar -->
 <?php include 'navBar.php';?> 
        
<div id="div2">
  <div>
    <h2>Contact Us</h2>
  </div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="unnamed.jpg" alt="Avatar" style="width:300px;height:300px;">
    </div>
    
    <div class="flip-card-back">
      <h1>Georges Yazigi</h1> 
      <p>Computer Science</p> 
      <p>We love that guy</p>
      <p>+96179148885</p>
      <h5>georgioyazigi@gmail.com</h5>
    </div>
  </div>
</div>
</div>
<br>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
    <img src="paul.jpeg" alt="Avatar" style="width:300px;height:300px;">
    </div>
    
    <div class="flip-card-back">
      <h1>Paul Khawaja</h1> 
      <p>Computer Science</p> 
      <p>We love that guy too :p</p>
      <p>+96176538235</p>
      <h5>Khawajapaul@hotmail.com</h5>
    </div>
  </div>
</div>
</div>
    </body>

    
</html>