<?php
date_default_timezone_set('Asia/Beirut');
$date= date('d-m-y h:i:s');
$location="Contact Us page  opened";
include '../utilities/Utilities.php';
writeToLog($date,$location);
?>
<!DOCTYPE html>
<html>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <head>
        <title>Home Page</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/bootstrap.css">
<link href="css/datatables.min.css" rel="stylesheet">
<link rel="stylesheet" href="css/normalize.css">
<link rel="stylesheet" href="../dist/jBox.all.css">
<link rel="stylesheet" href="css/demo.css">
<link rel="stylesheet" href="css/playground-avatars.css">
<link rel="stylesheet" href="css/playground-inception.css">
<link rel="stylesheet" href="css/playground-login.css">
<link rel="stylesheet" href="css/w3.css">


  <script src="js/jquery-3.5.0.js"></script>
        
    </head>
        
    <body>
 <!-- NavBar -->
 <?php include 'navBar.php';?> 
   
<div style="display: none" id="signup" >
                    <div>
                    <div id="uname_response" ></div>
                    <input class="textbox" type="text" id="txt_username" name="txt_username" placeholder="Username" />
                    </div>
                    <div>
                    <br>
                    <div id="email_response" ></div>
                    <input class="textbox" type="email" name="email" placeholder="Email" id="txt_email"/>
                    </div>
                    <div>
                    <br>
                    <input class="textbox" type="password" name="Password" placeholder="Password" id="txt_Password"/>
                    </div>
                    <div>
                    <input class="textbox" type="password" name="Password2" placeholder="Confirm Password" id="txt_Password2"/>
                    <div id="password_response" ></div>
                    </div>
                    <br>
                    <button name="register" id="reg_btn" class="inception-modal-button" data-inception-tooltip="Register">Sign Up</button>
                
                  
</div>
<div style="display: none" id="login">
                    <div>               
                    <input class="textbox" type="text" name="uname" placeholder="Username" required id="username">
                   
                    </div>           
                    <div>
                    <br>
                    <input class="textbox" name="upwd" type="password" placeholder="Password" required id="password" >
                    </div>
                    <div>
                    <br>
                    <button type="Button"  value="submit" id="but_submit">Log In</button>
                    </div>
                    <div>
                    <span style="color:#FF0000;"></span>
                    </div>
                    <div>
                    <p>Not Registered?<button class="inception-modal-button" data-inception-tooltip="Create A New Account">Register</button></p>

                    </div>
</div>      





<div id="div2">
  <div>
    <h2>Contact Us</h2>
  </div>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
      <img src="unnamed.jpg" alt="Avatar" style="width:300px;height:300px;">
    </div>
    
    <div class="flip-card-back">
      <h1>Georges Yazigi</h1> 
      <p>Computer Science</p> 
      <p>We love that guy</p>
      <p>+96179148885</p>
      <h5>georgioyazigi@gmail.com</h5>
    </div>
  </div>
</div>
</div>
<br>
<div class="flip-card">
  <div class="flip-card-inner">
    <div class="flip-card-front">
    <img src="paul.jepg" alt="Avatar" style="width:300px;height:300px;">
    </div>
    
    <div class="flip-card-back">
      <h1>Paul Khawaja</h1> 
      <p>Computer Science</p> 
      <p>We love that guy too :p</p>
      <p>+96176538235</p>
      <h5>Khawajapaul@hotmail.com</h5>
    </div>
  </div>
</div>
</div>


<script src="../dist/jBox.all.js"></script>
  <script src="js/demo.js"></script>
  <script src="js/playground-avatars.js"></script>
  <script src="js/playground-inception.js"></script>
  <script src="js/playground-login.js"></script>

  <script src="js/loginsignup.js"></script>

    </body>

    
</html>