<?php

session_start();

date_default_timezone_set('Asia/Beirut');
$date= date('d-m-y h:i:s');
$location="Categories Index page  opened";
include '../utilities/Utilities.php';
writeToLog($date,$location);
?>
<!DOCTYPE html>
<html>
    
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <head>
        <title>Home Page</title>
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link href="css/datatables.min.css" rel="stylesheet">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="../dist/jBox.all.css">
        <link rel="stylesheet" href="css/demo.css">
        <link rel="stylesheet" href="css/playground-avatars.css">
        <link rel="stylesheet" href="css/playground-inception.css">
        <link rel="stylesheet" href="css/playground-login.css">
        <link rel="stylesheet" href="css/w3.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 



  <script src="js/jquery-3.5.0.js"></script>
        
 
    </head>
        
    <body>
 <!-- NavBar -->
 <?php include 'navBar.php';?> 
    <div id="uname" name="<?php echo($_SESSION["uName"]);?>"></div>
<div class="container">
  <div class="jumbotron">
   <table id="" class="w3-table" cellspacing="0" width="100%">
     
     <tbody id="orderTable" class="Table tbody">
     </tbody>
     
   </table>
   </div>
   <table id="" class="w3-table" cellspacing="0" width="100%">
   <thead>
       <tr>
     <td><div  class='cart'><p><input  class='cart' id='checkout' type='button' style="font-weight: bold;" value='PROCEED TO CHECKOUT'></input></p></div></td>
     </tr>
     </thead>
      <tbody id="orderGrandPriceTable" class="Table tbody">

      </tbody>
    </table>

   <table id="" class="w3-table-all w3-hoverable" cellspacing="0" width="100%">
     <thead>
       <tr class="w3-light-grey">
       <th >Product Name</th>
       <th >Product Quantity</th>
       <th>Total</th>
       <th><img src='img/trash.png' width='25' height='25'/></th>
       </tr>
     </thead>
     <tbody style="text-transform: uppercase;  font-weight: bold;" id="orderdetailsTable" class="Table tbody">

     </tbody>
    
   </table>
   <table id="" class="w3-table-all w3-hoverable" style="visibility: hidden;" cellspacing="0" width="0%">
      
      <tbody id="itemTable" class="Table tbody">

      </tbody>
    </table>




</div>
  







<script src="../dist/jBox.all.js"></script>
  <script src="js/demo.js"></script>
  <script src="js/playground-avatars.js"></script>
  <script src="js/playground-inception.js"></script>
  <script src="js/playground-login.js"></script>

  <script src="js/basket-user.js"></script>

</body>

    
</html>