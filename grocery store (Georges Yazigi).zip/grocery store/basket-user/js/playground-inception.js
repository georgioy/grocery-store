$(document).ready(function () {

  $('#Login').on('click', function () {
    openInceptionModal();
  });

});

var offsetLevel = 0;

function openInceptionModal() {
  if (offsetLevel > 5) {
    offsetLevel = 0;
  }

  new jBox('Modal', {
    width: 360,
    addClass: 'inception-modal',
    overlayClass: 'inception-overlay',
    zIndex: 'auto',
    draggable: 'title',
    closeOnClick: false,
    closeButton: 'title',
    title: 'Login ',
    offset: {
      x: offsetLevel * 15,
      y: offsetLevel * 15
    },
    content: $('#login'),
    onCreated: function () {
      // Add tooltip
      this.tooltip = new jBox('Tooltip', {
        theme: 'TooltipBorder',
        attach: '[data-inception-tooltip]',
        getContent: 'data-inception-tooltip',
        zIndex: 'auto',
        delayOpen: 1600
      });

      // Add button event
      this.content.find('.inception-modal-button').on('click', function () {
        openInceptionModalSignUp();
      });
    },
   
  }).open();

  
}
function openInceptionModalSignUp() {
  if (offsetLevel > 5) {
    offsetLevel = 0;
  }

  new jBox('Modal', {
    width: 360,
    addClass: 'inception-modal',
    overlayClass: 'inception-overlay',
    zIndex: 'auto',
    draggable: 'title',
    closeOnClick: false,
    closeButton: 'title',
    title: 'Sign Up',
    offset: {
      x: offsetLevel * 15,
      y: offsetLevel * 15
    },
    content: $('#signup'),
    onCreated: function () {
      // Add tooltip
      this.tooltip = new jBox('Tooltip', {
        theme: 'TooltipBorder',
        attach: '[data-inception-tooltip]',
        getContent: 'data-inception-tooltip',
        zIndex: 'auto',
        delayOpen: 1600
      });

      // Add button event
      this.content.find('.inception-modal-button').on('click', function () {
        openInceptionModal();
      });
    },
    
  }).open();

  
}

