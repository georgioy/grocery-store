$(document).ready(function(){
  var username = $("body").find("#uname").attr("name");
  getUnpaidorder(username);

	function getUnpaidorder(uname) 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_orders.php",
      data:({op:3,unm:uname}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==null){
          $(':input[type="button"]').prop('disabled', true);
        }
        else{
          $(':input[type="button"]').prop('disabled', false);
          data=JSON.parse(xhr.responseText);
          populateUnpaidOrder(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }
  var globalOrderID;
  function populateUnpaidOrder(data)
  {
    if(data.length>0){
      $("#orderTable").empty();
      $.each(data, function(index, row){
        var
         uordr="<tr class='w3-light-grey'>";
         uordr+="<td id='tdoDate' name="+row.order_ID+"><b style='font-size:28px;'>ORDER </b><i class='fa fa-calendar-o' style='font-size:28px;' aria-hidden='true'></i><b style='font-size:24px;'> "+row.order_DATE+"</b></td>"
         uordr+="</tr>"
        $("#orderTable").append(uordr);
      });
      globalOrderID= $("body").find("#tdoDate").attr("name");
      getorderDetails(globalOrderID);
      getorderDetailsGrandTotal(globalOrderID);
    }
  }


 


  
  function getorderDetails(oid) 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_orderDetails.php",
      data:({op:0,orderID:oid}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        data=JSON.parse(xhr.responseText);
        if(data==null){
          $(':input[type="button"]').prop('disabled', true);
        }
        else{
          $(':input[type="button"]').prop('disabled', false);
          populateOrderdetails(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }
  function populateOrderdetails(data)
  {
    if(data.length>0){
      $("#orderdetailsTable").empty();
      $.each(data, function(index, row){
        var
         ordr="<tr >";
         ordr+="<td id='tdoPname' name="+row.order_ID+"><div id='prodName' name="+row.order_Product_Name+">"+row.order_Product_Name+"</td>"
         ordr+="<td id='tdoPQuant'>"
         ordr+="<div id='oDID' class='odid'  name="+row.order_Details_ID+"><p class='plus-minus'><input type='image' src='img/minus.png' id='minus1' width='20' height='20' class='minus'/><input id='qty' type='text'  disabled='true' value='"+row.order_Product_Quantity+"' style='width:50px;text-align:center;' class='qty'/><input type='image' id='add1' src='img/plus.png' width='20' height='20' class='add'/></p></div>"
         ordr+="</td>"
         ordr+="<td id='tdoPTtl' ><div id='ttl' name="+row.order_Total_Price+"><p>LBP "+row.order_Total_Price+"</p></div name="+row.order_Details_ID+"></td>"
         ordr+="<td><div id='delete'  name="+row.order_Details_ID+" ><input type='image' src='img/delete.png' width='20' height='20' class='delete'/></div></td>"
         ordr+="</tr>"

        $("#orderdetailsTable").append(ordr);
       
      });
    }
  }
  $(function () {
    $("body").on("click",".delete", function(){
      if (confirm("Are you sure you want to delete this item ?")){
      var id=$(this).closest('div').attr("name");
      
      deleteOrderDetail(id);
      $(this).closest("tr").remove();	
      OrderID= $("body").find("#tdoDate").attr("name");
       getorderDetails(OrderID);
       getorderDetailsGrandTotal(OrderID);}
       
       
    });
  });
  
  function deleteOrderDetail(val) 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_orderDetails.php",
      data:({op:5,id:val}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
        //  data=JSON.parse(xhr.responseText);
       //   populateUsers(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }
  var $GlobalQty=0;
  $(function () {
    $("body").on("click",".add", function(){
       var $qty=$(this).closest('p').find('.qty');
       var currentVal = parseInt($qty.val());
       if (!isNaN(currentVal)) {
      $qty.val(currentVal + 1);
       }
      var oDID=$(this).closest('div').attr("name");
      var quantvalue=$qty.val();
      var $prodName=$(this).closest('p').parents("tr").find("#prodName").attr("name");
      var oID=$(this).closest('p').parents("tr").find("#tdoPname").attr("name");
      getItem($prodName,quantvalue,oDID,oID);
     

    });
    $("body").on("click",".minus", function(){
        var $qty=$(this).closest('p').find('.qty');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal) && currentVal > 1) {
            $qty.val(currentVal - 1);
        }
        var oDID=$(this).closest('div').attr("name");
      var quantvalue=$qty.val();
      var $prodName=$(this).closest('p').parents("tr").find("#prodName").attr("name");
      var oID=$(this).closest('p').parents("tr").find("#tdoPname").attr("name");
      getItem($prodName,quantvalue,oDID,oID);
    });
});

function getItem(ItemName,qty,odid,oid) 
  {   
  $.ajax({
      type:'GET',
      url: "../utilities/ws_items.php",
      data:({op:5,itemName:ItemName}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          
          populateItem(data,ItemName,qty,odid,oid);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }

  function populateItem(data,ItemName,qty,odid,oid)
  {
    if(data.length>0){
      
      $("#itemTable").empty();
      $.each(data, function(index, row){
          var x=row.item_price;
          var y=row.item_discount;
          var newPrice;
        var
         
         itm="<tr>";
         itm+="<td  id='tdimg'><div id='itemName' name='"+row.item_name+"'></div></td>"
         itm+="</tr>"
         itm+="<tr>"
         if (y!=0 ) {
            newPrice = x - (x * y / 100);
            itm+="<td  id='tdprice'><div id='itmprice' name='"+ newPrice+"'></div></td>"
          }
          else
         itm+="<td id='tdprice'  ><div id='itmprice' name='"+ row.item_price+"'></div></td>"
         itm+="</tr>"
        $("#itemTable").append(itm);
      });
    }
    
    additemQuantity(ItemName,qty,odid,oid);
  }
  function additemQuantity(itemName,qty,odid,oid)
{
  
  var $itemprice = $("body").find("#itmprice").attr("name");
  
  
  var ttl=qty*parseInt($itemprice);
  UpdateItemQuantToOrderDetails(odid,oid,itemName,qty,(ttl).toString());
  OrderID= $("body").find("#tdoDate").attr("name");
  getorderDetails(OrderID);
  getorderDetailsGrandTotal(OrderID);
}
function UpdateItemQuantToOrderDetails(odid,oID,iName,iQuant,iTtl)
    {
      $.ajax({
        type:'GET',
        url: "../utilities/ws_orderDetails.php",
        data:({op:2,id:odid,oid:oID,pname:iName,pquant:iQuant,pttl:iTtl}),
      
        dataType:'json',
        timeout:5000,
        success: function(data, textStatus, xhr)
        {
          if(data==-1)
          alert("data couldn't be loaded");
          else{
          
            data=JSON.parse(xhr.responseText);
           
          }
        },
        error:function(xhr,status,errorThrown)
        {
          alert(status + errorThrown);
        }
      
      });
    }
  function  getorderDetailsGrandTotal(oID)
    {
      $.ajax({
        type:'GET',
        url: "../utilities/ws_orderDetails.php",
        data:({op:3,oid:oID}),
      
        dataType:'json',
        timeout:5000,
        success: function(data, textStatus, xhr)
        {
          if(data==null){
            $(':input[type="button"]').prop('disabled', true);
          }
          else{
            $(':input[type="button"]').prop('disabled', false);
            data=JSON.parse(xhr.responseText);
            populateGrandToTal(data);
          //////
          }
        },
        error:function(xhr,status,errorThrown)
        {
          alert(status + errorThrown);
        }
      
      });
    }
    var globalTotal=0;
    function populateGrandToTal(data)
    {
      if(data.length>0){
        $("#orderGrandPriceTable").empty();
        $.each(data, function(index, row){
          var Gttl=row.GLOBAL_ORDER_SUM;
          if(Gttl==null){
            $(':input[type="button"]').prop('disabled', true);
            Gttl=0;
            var
           oID="<tr >";
           oID+="<td  id='tdoID'><div class='grandTotal' name='"+Gttl+"'></div><i class='fa fa-shopping-cart' aria-hidden='true' style='font-size:28px;color:#4CAF50'></i><b style='font-size:24px;'> TOTAL PRICE: LBP "+Gttl+"</b></td>"
           oID+="</tr>"
          $("#orderGrandPriceTable").append(oID);
          }
          else{
            $(':input[type="button"]').prop('disabled', false);
            Gttl=row.GLOBAL_ORDER_SUM;
            var
           oID="<tr >";
           oID+="<td  id='tdoID'><div class='grandTotal' name='"+Gttl+"'></div><i class='fa fa-shopping-cart' aria-hidden='true' style='font-size:28px;color:#4CAF50'></i><b style='font-size:24px;'> TOTAL PRICE: LBP "+Gttl+"</b></td>"
           oID+="</tr>"
          $("#orderGrandPriceTable").append(oID);
          }
          
        });
      }
      globalTotal= $("body").find(".grandTotal").attr("name");//jbox on hover checkout btn
      new jBox('Mouse', {
        attach: '#checkout',
        position: {
          x: 'right',
          y: 'bottom'
        },
        
        content: '<b style="color:#4CAF50;"><i class="fa fa-check" style="font-size:28px;" aria-hidden="true"></i> PAY <p style="font-size:28px;color:#4CAF50">'+globalTotal+'</p> LBP</b>'
      });
      
    }
    $("body").on("click", "#checkout", function(){
      if (confirm("Are you sure you want to pay for this order?"))
      {}
      
    });
    
   
});