<?php 

include("DAL.class.php"); 


class orders {
 


 
	function __construct() {
		$this->dal = new DAL();
	
	}
				
 
	// function getUName() {
	// 	return $this->uname;
    // }
    
	
	function getAllOrders()
	{
		$sql="select * from orders order by order_ID desc";
		return $this->dal->getData($sql) ;	
	}
 
	
	
	function addOrder($date, $unm,$stts)
	{
		try{
		
		{
		
			$sql="Insert into orders (order_DATE,order_CUST_UNAME,order_STATUS_CODE) values ('$date','$unm','$stts')";
			$rows=$this->dal->executeData($sql);
			if(is_null($rows))
		return -1;
			else{
				
				return 1;

			}
		}
	}catch(Exception $ex)
	{
		throw $ex;
	}

	}
	
	
	function updateOrder($id,$date, $unm,$stts)
	{		
		$sql="update orders set order_DATE='$date',order_CUST_UNAME='$unm',order_STATUS_CODE=$stts where order_ID=$id";
		$rows=$this->dal->executeData($sql);
		if(is_null($rows))
		return -1;
			else{
				
				return 1;

			}
		
	}
	
	function getOrderByID($id)
	{
		$sql="select * from orders where order_ID=$id";		
		return $this->dal->getData($sql) ;	
		
	}

	function getUnpaidOrderByUnameCheck($unm)
	{
		$sql="select * from orders where order_CUST_UNAME='$unm' and order_STATUS_CODE=0";		
		return $this->dal->getData($sql) ;	
		
	}
	
	
		
		
		
}

?>