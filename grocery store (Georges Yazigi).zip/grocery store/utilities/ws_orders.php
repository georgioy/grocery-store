<?php

	header('Access-Control-Allow-Origin: *');
	require_once('orders.class.php');
	require_once('UTILS.class.php');
	$orders = new orders();
	$result;
	$op=$_GET["op"];
	
	try {	

			switch($op){
				case 0://Get All orders
				try{
				     $result=$orders->getAllOrders();
				}catch(Exception $ex)
				{
					UTILS::write_log($ex->getMessage());
				}
				break;

				case 1://Add orders row to the order Table
					try{
				     if(isset($_GET["date"],$_GET["unm"],$_GET["stts"]))
					 $date = $_GET["date"];
      				 $uname = $_GET["unm"];
					 $status = $_GET["stts"];

					 $result=$orders->addOrder($date,$uname,$status);
					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;

				case 2://update order
					try{
					 if(isset($_GET['id'],$_GET["date"],$_GET["unm"],$_GET["stts"]))
					 $id=$_GET['id'];
					 $date = $_GET["date"];
					 $uname = $_GET["unm"];
					 $status=$_GET["stts"];
					   
					  $result=$orders->updateOrder($id,$date,$uname,$status);
					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;

				case 3://	 get Unpaid Order By Uname Check($unm)
					try{
					 if(isset($_GET["unm"]))
					 $uname = $_GET["unm"];
					   
					  $result=$orders->getUnpaidOrderByUnameCheck($uname);
					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;
				
			}
			
		
	}
	catch(Exception $ex)
		{
			UTILS::write_log($ex->getMessage());
			$result=-1;
		}
		
	
		header("Content-type:application/json"); 						
		
		echo json_encode($result);
	
