<?php 

include("DAL.class.php"); 


class orderDetails {
 
	function __construct() {
		$this->dal = new DAL();
	
	}
				
 
	// function getUName() {
	// 	return $this->uname;
    // }
    
	
	function getAllOrders()
	{
		$sql="select * from orderdetails order by order_ID desc";
		return $this->dal->getData($sql) ;	
	}
 
	
	
	function addOrderDetails($oID,$prodNm, $prodQuant,$ttl)
	{
		try{
		
		{
		
			$sql="Insert into orderDetails (order_ID,order_Product_Name,order_Product_Quantity,order_Total_Price) values ('$oID','$prodNm','$prodQuant','$ttl')";
			$rows=$this->dal->executeData($sql);
			if(!is_null($rows))
				return 1;
		}
	}catch(Exception $ex)
	{
		throw $ex;
	}

	}
	
	
	function updateOrderDetails($id,$oID,$prodNm, $prodQuant,$ttl)
	{		
		$sql="update orderDetails set order_ID='$oID',order_Product_Name='$prodNm',order_Product_Quantity=$prodQuant,order_Total_Price='$ttl' where order_Details_ID =$id";
		$rows=$this->dal->executeData($sql);
		if(is_null($rows))
		return -1;
			else{
				
				return 1;

			}
		
	}
	
	function getOrderDetails_By_Order_ID($id)
	{
		$sql="select * from orderDetails where order_ID=$id";		
		return $this->dal->getData($sql) ;	
		
	}
	
	
	function getOrderDetails_GrandPrice_By_Order_ID($id)
	{
		$sql="SELECT SUM(order_Total_Price) AS 'GLOBAL_ORDER_SUM'   from orderdetails where order_ID=$id";		
		return $this->dal->getData($sql) ;	
		
	}
	function getOrderItemDetails_By_Order_ID_and_Product_Name($id,$prodNm)
	{
		$sql="select * from orderDetails where order_ID=$id AND order_Product_Name='$prodNm'";		
		return $this->dal->getData($sql) ;	
		
	}
	function deleteByoDID($id)
	{
		$sql="delete from orderDetails where order_Details_ID=$id";
		$this->dal->executeData($sql);		
	}
}

?>