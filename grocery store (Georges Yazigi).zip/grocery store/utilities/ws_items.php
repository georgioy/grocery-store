<?php

	header('Access-Control-Allow-Origin: *');
	require_once('items.class.php');
	require_once('UTILS.class.php');
	
	$items = new items();
	$result;
	$op=$_GET["op"];
	
	try {	

			switch($op){
				case 0://Get All items
				try{

				   $result=$items->getAllItems();

				}catch(Exception $ex)
				{
					UTILS::write_log($ex->getMessage());
				}
				break;

				case 1://Delete item row from Table items(Admin Side)
					try{
					 $id=$_GET["id"];
					 $result=$items->deleteByID($id);//Delete The item by ID from the DB

					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;

				case 2://Add item row to the categories Table

					try{
					 if(isset($_GET["img"],$_GET["name"],$_GET["desc"],$_GET["quant"],$_GET["price"],$_GET["disc"],$_GET["itemCatName"]))
					 $img = $_GET["img"];
      				 $name = $_GET["name"];
                     $desc = $_GET["desc"];
                     $quant = $_GET["quant"];
                     $price = $_GET["price"];
                     $disc = $_GET["disc"];
                     $itemCatName = $_GET["itemCatName"];

					 $result=$items->addItem($img,$name,$desc,$quant,$price,$disc,$itemCatName);//Adds a New Item To DB
					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;

				case 3://update item
					try{
					 if(isset($_GET['id'],$_GET["img"],$_GET["name"],$_GET["desc"],$_GET["quant"],$_GET["price"],$_GET["disc"],$_GET["itemCatName"]))
					 $id=$_GET['id'];
					 $img = $_GET["img"];
      			     $name = $_GET["name"];
                     $desc = $_GET["desc"];
                     $quant = $_GET["quant"];
                     $price = $_GET["price"];
                     $disc = $_GET["disc"];
                     $itemCatName = $_GET["itemCatName"];
					   
					 $result=$items->updateItem($id,$img,$name,$desc,$quant,$price,$disc,$itemCatName);
					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;

				case 4:
					try{
						 if(isset($_GET["itemCatName"]))
						 $itemCatName = $_GET["itemCatName"];
						   
						 $result=$items->getItemsByCatName($itemCatName);
						}catch(Exception $ex)
						{
							UTILS::write_log($ex->getMessage());
						}
				break;

				case 5:
					try{
						 if(isset($_GET["itemName"]))
						 $itemName = $_GET["itemName"];
						   
						 $result=$items->getItemByName($itemName);
						}catch(Exception $ex)
						{
							UTILS::write_log($ex->getMessage());
						}
				
			}
			
	
				
		
		
	}
	catch(Exception $ex)
		{
			UTILS::write_log($ex->getMessage());
			$result=-1;
		}
		
	
		header("Content-type:application/json"); 						
		
		echo json_encode($result);
	
