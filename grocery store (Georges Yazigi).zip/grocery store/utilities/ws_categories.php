<?php

	header('Access-Control-Allow-Origin: *');
	require_once('categories.class.php');
	require_once('UTILS.class.php');
	
	$categorie = new Categories();
	$result;
	$op=$_GET["op"];
	
	try {	

			switch($op){
			    case 0://Get All categories

				try{
				 $result=$categorie->getAllCategories();

				}catch(Exception $ex)
				{
					UTILS::write_log($ex->getMessage());
				}
				break;

				case 1://Delete categorie row from Table categories(Admin Side)

					try{
					 $id=$_GET["id"];

					 $result=$categorie->deleteByID($id);//Delete The categorie by ID from the DB

					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;

				case 2://Add categorie row to the categories Table
					try{
					 if(isset($_GET["img"],$_GET["name"]))
					 $img = $_GET["img"];
      				 $name = $_GET["name"];

					 $result=$categorie->addCategorie($img,$name);//Adds a New cat To DB

					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;
				case 3://update categorie
					try{
					 if(isset($_GET['id'],$_GET["img"],$_GET["name"]))
				 	 $id=$_GET['id'];
					 $img = $_GET["img"];
					 $name = $_GET["name"];
					   
					 $result=$categorie->updateCategorie($id,$img,$name);
					
					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;
				
			}
			
	
				
		
		
	}
	catch(Exception $ex)
		{
			UTILS::write_log($ex->getMessage());
			$result=-1;
		}
		
	
		header("Content-type:application/json"); 						
		
		echo json_encode($result);
	
