<?php 

function writeToLog($date,$location){
	if(!file_exists('log.txt')){
		file_put_contents('log.txt','');
	}
	$content=file_get_contents('log.txt')."$date\t$location\r";
	file_put_contents('log.txt',$content);

}


function getData($sql)
{		 	
   $servername = "localhost";
   $username="root";
   $password="";
   $dbname="fall2020";
	
	$conn = @new mysqli($servername,$username,$password,$dbname);	
					
	$result =$conn->query($sql);
		
	$rows = array();
			
	if($result->num_rows > 0) {
				
		while($row = mysqli_fetch_assoc($result)) {
			$rows[] = $row;
		}						
	}
	
	return $rows;			
}

function executeData($sql)
{		 
   $servername = "localhost";
   $username="root";
   $password="";
   $dbname="fall2020";
	
	$conn = @new mysqli($servername,$username,$password,$dbname);	
					
	$conn->query($sql);				
}

function getImage($type)
{
	return $type==1?"admin":"user";
}
?>

