<?php 

include("DAL.class.php"); 


class Categories {
 

    private $img;
    private $name;

 
	function __construct() {
		$this->dal = new DAL();
	
	}
	function getAllCategories()
	{
		try{
		$sql="select * from categories order by cat_id desc";
		return $this->dal->getData($sql) ;
	}catch(Exception $ex)
	{
		throw $ex;
	}	
	}
 
	function deleteByID($id)
	{
		$sql="delete from categories where cat_id=$id";
		$this->dal->executeData($sql);		
	}
	
	
	function addCategorie($img, $name)
	{
		try{
		if(!$this->checkBeforAddCategorie($name))
		{
			
			$sql="Insert into categories (cat_img,cat_name) values ('$img','$name')";
			$rows=$this->dal->executeData($sql);
			if(!is_null($rows))
				return 1;
		}
		else
			return $data="categorie already exists";
	}catch(Exception $ex)
	{
		throw $ex;
	}

	}
	
	
	function updateCategorie($id,$img, $name)
	{		
		try{
		$sql="update categories set cat_img='$img',cat_name='$name' where cat_id=$id";
		$rows=$this->dal->executeData($sql);
		if(is_null($rows))
		return -1;
			else{
				
				return 1;

			}
		}
		catch(Exception $ex)
		{
			throw $ex;
		}
		
	}
	
	function checkBeforAddCategorie($name)//Checks if the categorie name exists in the DB
	{		
		try{
			$sql="select * from categories where cat_name='$name' ";				
			$rows=$this->dal->getData($sql);
			
			if(is_null($rows))
				return 0;//it's ok, no shuch categorie exists
			else
				return 1;//a categorie already have this cat name in the DB
		}
		catch(Exception $ex)
		{
			throw $ex;
		}
				
	}
	
	
	function getCatByID($id)
	{
		$sql="select * from categories where cat_id=$id";		
		return $this->dal->getData($sql) ;	
		
	}
	
	
		
		
		
}

?>