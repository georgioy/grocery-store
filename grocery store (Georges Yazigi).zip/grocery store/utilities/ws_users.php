<?php

	header('Access-Control-Allow-Origin: *');
	require_once('users.class.php');
	require_once('UTILS.class.php');
	

	$user = new Users();
	$result;
	$op=$_GET["op"];
	try {	

			switch($op){
				case 0://Get All Users
				   $result=$user->getAllUsers();
				break;

				case 1://Check For User Login
					try{
				   	 if(isset($_GET["uname"],$_GET["upwd"])){
							$uname=$_GET["uname"];
							$upwd=$_GET["upwd"];
							$result=$user->checkUser($uname, $upwd);
							//Checks if Username and Password are Correct
							if($result!=-1){
								//php sessions
								$_SESSION["uid"]=$result[0]["u_id"];
								$_SESSION["uName"]=$result[0]["u_uname"];
								$_SESSION["utype"]=$result[0]["u_type"];

							}

							$result=(int)($result[0]["u_type"]);

						}
					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break; 

				case 2: 
					
				break;
				case 3://Delete User row from Table Users(Admin Side)
					try{
					 $id=$_GET["id"];

					 $result=$user->deleteByID($id);//Delete The user by ID from the DB
					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;

				case 4://Add User row to the Users Table
					try{
					 if(isset($_GET["email"],$_GET["uname"],$_GET["pwd"],$_GET["type"]))
					 $email = $_GET["email"];
      				 $uname = $_GET["uname"];
					 $pwd = $_GET["pwd"];
					 $type=$_GET["type"];

					 $result=$user->addUser($email,$uname,$pwd,$type);//Adds a New User To DB
					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;
				case 5://update User
					try{
					 if(isset($_GET['id'],$_GET["email"],$_GET["uname"],$_GET["type"]))
					 $id=$_GET['id'];
					 $email = $_GET["email"];
					 $uname = $_GET["uname"];
					 $type=$_GET["type"];
					   
					 $result=$user->updateUser($id,$email,$uname,$type);
					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;
				case 6://check for user on sign up if user already exists in DB
					try{
					 if(isset($_GET["uname"]))
					 $uname=$_GET["uname"];
					 $result=$user->checkforUser($uname);//Checks if the username in the DB if it's available or already taken
					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
				break;

				case 7://check for user on sign up if email already exists in DB
					try{
					 if(isset($_GET["email"]))
					 $email=$_GET["email"];
					 $result=$user->checkforEmail($email);//Checks if the email in the DB if is available or already taken
					}catch(Exception $ex)
					{
						UTILS::write_log($ex->getMessage());
					}
					break;
				case 8://search for user by name
					try{
						 $val="";
						 if(isset($_GET["srh"]))
						 $val=$_GET["srh"];
						 $result=$user->getUsers($val);
						}catch(Exception $ex)
						{
							UTILS::write_log($ex->getMessage());
						}
						break;
			}
			
	
				
		
		
	}
	catch(Exception $ex)
		{
			UTILS::write_log($ex->getMessage());
			$result=-1;
		}
		
	
		header("Content-type:application/json"); 						
		
		echo json_encode($result);

?>
