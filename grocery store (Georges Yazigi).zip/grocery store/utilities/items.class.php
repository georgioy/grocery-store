<?php 

include("DAL.class.php"); 


class items {
 

    private $img;
    private $name;
	private $disc;

 
	function __construct() {
		$this->dal = new DAL();
	
    }
    //get all items oredered desc
	function getAllItems()
	{
		try{
		$sql="select * from items order by item_id desc";
		return $this->dal->getData($sql) ;
	}catch(Exception $ex)
	{
		throw $ex;
	}	
	}
    //delete item by ID
	function deleteByID($id)
	{
		$sql="delete from items where item_id=$id";
		$this->dal->executeData($sql);		
	}
	
	//add item
	function addItem($img, $name, $desc, $quantity, $price, $discount, $CatName)
	{
		try{
		if(!$this->checkBeforAddItem($name))
		{
			
			$sql="Insert into items (item_img,item_name,item_desc,item_quantity,item_price,item_discount,item_cat_Name) values ('$img','$name','$desc','$quantity','$price','$discount','$CatName')";
			$rows=$this->dal->executeData($sql);
			if(!is_null($rows))
				return 1;
		}
		else
			return $data="item already exists";
	}catch(Exception $ex)
	{
		throw $ex;
	}

	}
	
	
	function updateItem($id,$img, $name, $desc, $quantity, $price, $discount, $CatName)
	{		
		try{
		$sql="update items set item_img='$img',item_name='$name',item_desc='$desc',item_quantity='$quantity',item_price='$price',item_discount='$discount',item_cat_Name='$CatName' where item_id=$id";
		$rows=$this->dal->executeData($sql);
		if(is_null($rows))
		return -1;
			else{
				
				return 1;

			}
		}
		catch(Exception $ex)
		{
			throw $ex;
		}
		
	}
	
	function checkBeforAddItem($name)//Checks if the item name exists in the DB
	{		
		try{
			$sql="select * from items where item_name='$name' ";				
			$rows=$this->dal->getData($sql);
			
			if(is_null($rows))
				return 0;//it's ok, no shuch item exists
			else
				return 1;//an item already have this name in the DB
		}
		catch(Exception $ex)
		{
			throw $ex;
		}
				
	}
	
	function getItemsByCatName($catName)	//gets an item by catName
	{
		$sql="select * from items where item_cat_Name='$catName'";		
		return $this->dal->getData($sql) ;	
		
	}
	
	function getItemByName($itemName)	//gets an item by Name
	{
		$sql="select * from items where item_name='$itemName'";		
		return $this->dal->getData($sql) ;	
		
	}
	
	
		
		
		
}

?>