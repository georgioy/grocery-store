<?php

	header('Access-Control-Allow-Origin: *');
	require_once('orderDetails.class.php');
	require_once('UTILS.class.php');
	$orderDetails = new orderDetails();
	$result;
	$op=$_GET["op"];
	
	try {	

			switch($op){
				case 0://Get All orderDetails by order_ID
				
					try{
						 if(isset($_GET['orderID']))
					     $id=$_GET['orderID'];
						 $result=$orderDetails->getOrderDetails_By_Order_ID($id);
						}catch(Exception $ex)
						{
							UTILS::write_log($ex->getMessage());
						}
					break;
					case 1://add orderDetails	
						try{
						 if(isset($_GET['oid'],$_GET["pname"],$_GET["pquant"],$_GET["pttl"]))
						 $oid=$_GET['oid'];
						 $prodName = $_GET["pname"];
						 $prodQuant = $_GET["pquant"];
						 $prodTtl=$_GET["pttl"];
						   
			 $result=$orderDetails->addOrderDetails($oid,$prodName,$prodQuant,$prodTtl);
						}catch(Exception $ex)
						{
							UTILS::write_log($ex->getMessage());
						}
					break;
					case 2://update orderDetails	
						try{
			if(isset($_GET['id'],$_GET['oid'],$_GET["pname"],$_GET["pquant"],$_GET["pttl"]))
							$id=$_GET['id'];
							$oid=$_GET['oid'];
							$prodName = $_GET["pname"];
							$prodQuant = $_GET["pquant"];
							$prodTtl=$_GET["pttl"];
							  
		$result=$orderDetails->updateOrderDetails($id,$oid,$prodName,$prodQuant,$prodTtl);
						}catch(Exception $ex)
						{
							UTILS::write_log($ex->getMessage());
						}
					break;
					case 3://get Sum total
						try{
							if(isset($_GET['oid']))
							$oid=$_GET['oid'];

						$result=$orderDetails->getOrderDetails_GrandPrice_By_Order_ID($oid);
						}catch(Exception $ex)
						{
							UTILS::write_log($ex->getMessage());
						}
					break;
					case 4://check if the item already in the orderdetail according to the oid
						try{
							if(isset($_GET['oid'],$_GET["pname"]))
							$oid=$_GET['oid'];
							$prodName = $_GET["pname"];
						$result=$orderDetails->getOrderItemDetails_By_Order_ID_and_Product_Name($oid,$prodName);
						}catch(Exception $ex)
						{
							UTILS::write_log($ex->getMessage());
						}
					break;
					case 5://Delete data row from Table orderDetails

						try{
						 $id=$_GET["id"];
	
						 $result=$orderDetails->deleteByoDID($id);//Delete The row by ID from the DB
	
						}catch(Exception $ex)
						{
							UTILS::write_log($ex->getMessage());
						}
					break;
					
			}
			
		
	}
	catch(Exception $ex)
		{
			UTILS::write_log($ex->getMessage());
			$result=-1;
		}
		
	
		header("Content-type:application/json"); 						
		
		echo json_encode($result);
	
