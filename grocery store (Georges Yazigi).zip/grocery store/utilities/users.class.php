<?php 

include("DAL.class.php"); 
session_start();
class Users {
 

    private $uname;
    private $email;
	private $pwd;
	private $type;	

 
	function __construct() {
		$this->dal = new DAL();
	
	}
				
 
	// function getUName() {
	// 	return $this->uname;
    // }
    
	
	function getAllUsers()
	{
		$sql="select * from users order by u_id desc";
		return $this->dal->getData($sql) ;	
	}
	function getUsers($val)//search users
	{
		$sql="select * from users ";
		if($val!=""){
			$where="where u_uname like'$val%'";
			$sql.=$where;
		}
		return $this->dal->getData($sql) ;	
	}
 
	function deleteByID($id)//delete user
	{
		$sql="delete from users where u_id=$id";
		$this->dal->executeData($sql);		
	}
	
	
	function addUser($eml, $unm, $pd, $tp)
	{
		try{
		if(!$this->checkBeforAddUser($unm,$eml))
		{
			$pwd=md5($pd);
			$sql="Insert into users (u_email,u_uname,u_pwd,u_type) values ('$eml','$unm','$pwd',$tp)";
			$rows=$this->dal->executeData($sql);
			if(!is_null($rows))
				return 1;
		}
		else
			return $data="User already exists";
	}catch(Exception $ex)
	{
		throw $ex;
	}

	}
	
	
	function updateUser($id,$eml, $unm, $tp)
	{		
		$sql="update users set u_email='$eml',u_uname='$unm',u_type=$tp where u_id=$id";
		$rows=$this->dal->executeData($sql);
		if(is_null($rows))
		return -1;
			else{
				
				return 1;

			}
		
	}
	
	function checkBeforAddUser($uname, $uemail)//Checks if Username and email are available in the DB before the user registers a new account
	{		
		try{
			$sql="select * from users where u_uname='$uname' or u_email='$uemail'";				
			$rows=$this->dal->getData($sql);
			
			if(is_null($rows))
				return 0;
			else
				return 1;
				
		}
		catch(Exception $ex)
		{
			throw $ex;
		}
				
	}
	
	function checkUser($uname, $upwd)//Checks if Username and Password are Correct and available in the DB
	{		
		try{
			$pwd=md5($upwd);
			$sql="select * from users where u_uname='$uname' and u_pwd='$pwd'";
			$rows=$this->dal->getData($sql);
			
			if(is_null($rows))
				return -1;
			else{
				$user=$rows;
				return $user;

			}
				
				
		}
		catch(Exception $ex)
		{
			throw $ex;
		}
		
	}
	function checkforUser($uname)//Checks if the username in the DB if it's available or already taken
	{		
		try{
			$sql="select * from users where u_uname='$uname' ";				
			$rows=$this->dal->getData($sql);
			
			if(is_null($rows))
				return 1;//it's ok, no shuch username exists
			else
				return 0;//a user already have this username in the DB
		}
		catch(Exception $ex)
		{
			throw $ex;
		}
				
	}
	function checkforEmail($uemail)//Checks if the email in the DB if it's available or already used
	{		
		try{
			$sql="select * from users where u_email='$uemail' ";				
			$rows=$this->dal->getData($sql);
			
			if(is_null($rows))
				return 1;//it's ok, no shuch email exists
			else
				return 0;//a user already have this email in the DB
		}
		catch(Exception $ex)
		{
			throw $ex;
		}
				
	}
	function getUserByID($id)
	{
		$sql="select * from users where u_id=$id";		
		return $this->dal->getData($sql) ;	
		
	}
	function getType() {
		return $this->type;
	}
	
	
		
		
		
}

?>