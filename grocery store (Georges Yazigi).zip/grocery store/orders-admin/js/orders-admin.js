$(document).ready(function(){

getOrders();
	function getOrders() 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_orders.php",
      data:({op:0}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          populateOrders(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }
  var globalID=-1;
  function populateOrders(data)
  {
    if(data.length>0){
      
      $("#myTable").empty();
      $.each(data, function(index, row){
        globalID=row.order_ID;

	

        var
         ordr="<tr>";
		 ordr+="<td id='tdDate'>"+row.order_DATE+"</td>"
		 ordr+="<td id='tdUname'>"+row.order_CUST_UNAME+"</td>"
		 ordr+="<td id='tdStatus' >"+row.order_STATUS_CODE+"</td>"
		 ordr+="<td><input id='orderDetails' type='button' class='btn btn-default' name='"+row.order_ID+"' value='Order Details' ></td>"
		 ordr+="</tr>"
		$("#myTable").append(ordr);
		$("body").on('click','#orderDetails', function(){
      var myModal = $('#orderDetails').jBox('Modal');
      myModal.setTitle('Order Details').setContent($('#orderDetailsModal'));
			getOrderDetails(globalID);
		});
		
      });
    }
  }
  
	

  function getOrderDetails(oID) 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_orderDetails.php",
      data:({op:0,orderID:oID}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          populateDetailsOrders(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }
  function populateDetailsOrders(data)
  {
    if(data.length>0){
      
      $("#DetailsTable").empty();
      $.each(data, function(index, row){
		globalID=row.order_ID;

        var
         ordrD="<tr>";
		 ordrD+="<td id='tdProdNm'>"+row.order_Product_Name+"</td>"
		 ordrD+="<td id='tdProdQuant'>"+row.order_Product_Quantity+"</td>"
		 ordrD+="<td id='tdTtlPrice' >"+row.order_Total_Price+"</td>"
		 ordrD+="</tr>"
        $("#DetailsTable").append(ordrD);
      });
    }
  }
 	

   
	
});