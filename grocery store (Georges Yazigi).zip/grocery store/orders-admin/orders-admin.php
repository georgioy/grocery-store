<head>
  <meta charset="utf-8">
  <title>Orders</title>

  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0">
  <!-- CSS -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="../dist/jBox.all.css">
  <link rel="stylesheet" href="css/demo.css">
  <link rel="stylesheet" href="css/playground-avatars.css">
  <link rel="stylesheet" href="css/playground-inception.css">
  <link rel="stylesheet" href="css/playground-login.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link href="css/datatables.min.css" rel="stylesheet">
  <link href="css/css?family=Roboto:400,500" rel="stylesheet">

  <script src="js/jquery-3.5.0.js"></script>


</head>

<body>
  <!-- NavBar -->
  <?php include 'navBar.php'; ?>
  <div class="container">
    <h2>Orders</h2>
    <table id="" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th class="th-sm">order DATE</th>
          <th class="th-sm">Username</th>
          <th class="th-sm">Status</th>
          <th class="Deleteth">Details</th>
        </tr>
      </thead>
      <tbody id="myTable" class="Table tbody">

      </tbody>
    </table>
  </div>

  <!-- order details Modal -->
  <div style="display: none" id="orderDetailsModal">
  
  <table id="" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th class="th-sm">Product Name</th>
          <th class="th-sm">Product Quantity</th>
          <th class="th-sm">Total Price</th>
        </tr>
        <tr>
        </tr>
      </thead>
      <tbody id="DetailsTable" class="Table tbody">

      </tbody>
    </table>
</div>

  <!-- jquery-lib -->
  <script language="javascript" src="js/jquery.min.js"></script>
  <!-- Scripts -->
  <script type="text/javascript" src="js/datatables.min.js"></script>
  <script language="javascript" src="js/bootsrap.min.js"></script>

  <script src="../dist/jBox.all.js"></script>
  <script src="js/demo.js"></script>
  <script src="js/playground-avatars.js"></script>
  <script src="js/playground-inception.js"></script>
  <script src="js/playground-login.js"></script>

  <script language="javascript" src="js/orders-admin.js"></script>

</body>

</html>