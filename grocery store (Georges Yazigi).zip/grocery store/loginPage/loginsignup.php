<!DOCTYPE html>
<html>
    <head>
        <title>login and Registration</title>
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>









    <div class="div">
        <div class="login-page">
            <div class="form">
                
                <div id="uname_response" ></div>
                    <input  type="text" id="txt_username" name="txt_username" placeholder="Username" />
                    <div id="email_response" ></div>
                    <input type="email" name="email" placeholder="Email" id="txt_email"/>
                    <input type="password" name="Password" placeholder="Password" id="txt_Password"/>
                    <input type="password" name="Password2" placeholder="Confirm Password" id="txt_Password2"/>
                    <div id="password_response" ></div>
                    <button name="register" id="reg_btn">Sign Up</button>
                    <p class="message">Already Registered? <a href="#">Login</a>   
                    </p>
              
              
               
                    <div>
                    <input type="text" name="uname" placeholder="Username" required id="username">
                    </div>           
                    <div>
                    <input name="upwd" type="password" placeholder="Password" required id="password" >
                    </div>
                    <div>
                    <button type="Button"  value="submit" id="but_submit">Log In</button>
                    </div>
                    <div>
                    <span style="color:#FF0000;"></span>
                    </div>
                    <div>
                    <p class="message">Not Registered? <a href="#">Register</a></p>
                    </div>
                
                
                
            </div>
            
        </div>
    </div>

    <div class="div1">

    </div>
        <script src="js/jquery-3.2.1.min.js">
        </script>
        <script src="js/loginsignup.js"></script>
    </body>
</html>