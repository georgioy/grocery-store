$(document).ready(function(){
	

	$(document).on('change', '#file', function(){
		var name = document.getElementById("file").files[0].name;
		var form_data = new FormData();
		var ext = name.split('.').pop().toLowerCase();
		if(jQuery.inArray(ext, ['gif','png','jpg','jpeg']) == -1) 
		{
		 alert("Invalid Image File");
		}
		var oFReader = new FileReader();
		oFReader.readAsDataURL(document.getElementById("file").files[0]);
		var f = document.getElementById("file").files[0];
		var fsize = f.size||f.fileSize;
		if(fsize > 2000000)
		{
		 alert("Image File Size is very big");
		}
		else
		{
		 form_data.append("file", document.getElementById('file').files[0]);
		 $.ajax({
		  url:"upload.php",
		  method:"POST",
		  data: form_data,
		  contentType: false,
		  cache: false,
		  processData: false,
		  beforeSend:function(){
		   $('#uploaded_image').html("<label class='text-success'>Image Uploading...</label>");
		  },   
		  success:function(data)
		  {
		   $('#uploaded_image').html(data);
		  }
		 });
		}
	   });



	var myModal = $('#additm').jBox('Modal');
 
myModal.setTitle('Add Item').setContent($('#addItem'));

	getItems();


	
	function getItems() 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_items.php",
      data:({op:0}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          populateItems(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }
  var globalID=-1;
  function populateItems(data)
  {
    if(data.length>0){
      
      $("#myTable").empty();
      $.each(data, function(index, row){
        globalID=row.item_id;
        var
         itm="<tr>";
		 itm+="<td id='tdimg'><div style='text-align: center;'><img id='image' name='"+row.item_img+"' height=75px width=100px src='upload/"+row.item_img+"'></div></td>"
		 itm+="<td id='tdname'>"+row.item_name+"</td>"
		 itm+="<td id='tddesc' >"+row.item_desc+"</td>"
		 itm+="<td id='tdquant' >"+row.item_quantity+"</td>"
		 itm+="<td id='tdprice' >"+row.item_price+"</td>"
		 itm+="<td id='tddisc' >"+row.item_discount+"</td>"
		 itm+="<td id='tdCatName' >"+row.item_cat_Name+"</td>"
		 itm+="<td><input type='button' class='btn btn-default'name='"+row.item_id+"' value='X' id='deletebtn'></td>"
		 itm+=" <td><input id='btn-edit'  type='button' class='btn btn-primary editbtn' value='Edit'></td>"
		 itm+="</tr>"
        $("#myTable").append(itm);
      });
    }
  }
 	
	//global variables to save the td values for the cancel button in edit mode
	var globalimage = '';
	var globalname = '';
	var globaldesc = '';
	var globalquantity = '';
	var globalprice = '';
	var globaldiscount = '';
	var globalitemCat = '';


	//Modal submit(add) button on click ;it displays the modal to add a new user
	$("#add").click(function(){
		
		valid=validateFields();
		
		if(valid)
		{
			var img=$("#uploadedImage").attr("name");
			var name=$("#name").val();
			var desc=$("#desc").val();
			var quant=$("#quant").val();
			var price=$("#price").val();
			var disc=$("#disc").val();
			var catName=$("#catName").val();
			
			
			$("#addItem").modal('hide');
			addItem(img,name,desc,quant,price,disc,catName);
			resetFields();
			getItems();
			
		}
		else
		alert("Fill all the rows")
		
	});
	

	
	
	//it resets the fields once the modal is closed
	function resetFields()
	{		
		$("#file").val("");
		$("#uploaded_image").html("");
		$("#name").val("");
		$("#desc").val("");
		$("#quant").val("");
		$("#price").val("");
		$("#disc").val("");
		$("#catName").val("");
	}

	//it validate if any of the fields are empty in the modal 
	function validateFields(){
		
		var resulti = $("#file").val()!="" ?true:false;
		var resultn= $("#name").val()!="" ?true:false;
		var resultd = $("#desc").val()!="" ?true:false;
		var resultq = $("#quant").val()!="" ?true:false;
		var resultp = $("#price").val()!="" ?true:false;
		var resultdi = $("#disc").val()!="" ?true:false;
		var resultc = $("#catName").val()!="" ?true:false;
		
		return resulti && resultn && resultd && resultq && resultp && resultdi && resultc;
	}

	function addItem(itemImg,itemName,itemDesc,itemQuant,itemPrice,itemDisc,itemCatName) 
	{  
	$.ajax({
		type:'GET',
		url: "../utilities/ws_items.php",
		data:({op:2,img:itemImg,name:itemName,desc:itemDesc,quant:itemQuant,price:itemPrice,disc:itemDisc,itemCatName:itemCatName}),
  
		dataType:'json',
		timeout:5000,
		success: function(data, textStatus, xhr)
		{
		  if(data==-1)
		  alert("data couldn't be loaded");
		  else{
			if(data=="item already exists")
			alert("item already exists");
			else{
				getitems();
			}
		  //  data=JSON.parse(xhr.responseText);
		 //   populateUsers(data);
		  }
		},
		error:function(xhr,status,errorThrown)
		{
		  alert(status + errorThrown);
		}
  
	});
	}
	

	//alert to make sure that the user want to delete the whole row
	//Delete item row from Table (Admin Side)
	$("body").on("click","#deletebtn", function(){//Delete X Button
		if (confirm("Are you sure you want to delete this Item?"))
		var id=$(this).attr("name");
		 id=id.substring(0);
		 deleteItem(id);
	 	$(this).closest("tr").remove();	
			
	});


	function deleteItem(val) 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_items.php",
      data:({op:1,id:val}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
        //  data=JSON.parse(xhr.responseText);
       //   populateUsers(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }

	//editButton
	$("body").on("click", "#btn-edit", function(){
		
		var img = $(this).parents("tr").find("#tdimg").find("#image").attr("name") ;
		globalimage = $(this).parents("tr").find("#tdimg").text();

		var name = $(this).parents("tr").find("#tdname").text();
		globalname = $(this).parents("tr").find("#tdname").text();

		var desc = $(this).parents("tr").find("#tddesc").text();
		globaldesc = $(this).parents("tr").find("#tddesc").text();

		var quant = $(this).parents("tr").find("#tdquant").text();
		globaldesc = $(this).parents("tr").find("#tdquant").text();

		var price = $(this).parents("tr").find("#tdprice").text();
		globaldesc = $(this).parents("tr").find("#tdprice").text();

		var disc = $(this).parents("tr").find("#tddisc").text();
		globaldesc = $(this).parents("tr").find("#tddisc").text();

		var itemcatName = $(this).parents("tr").find("#tdCatName").text();
		globaldesc = $(this).parents("tr").find("#tdCatName").text();

	
		$(this).parents("tr").find("td:eq(0)").html('<div style="text-align: center;"><img id="image" name="'+img+'" height=75px width=100px src="upload/'+img+'"></div><label for="image">Choose an image:</label><br><input type="file" name="file" id="file" /><br/><span id="uploaded_image"></span>');

        $(this).parents("tr").find("td:eq(1)").html('<input name="edit_name" value="'+name+'">');
		$(this).parents("tr").find("td:eq(2)").html('<input name="edit_desc" value="'+desc+'">');
		$(this).parents("tr").find("td:eq(3)").html('<input name="edit_quant" value="'+quant+'">');
		$(this).parents("tr").find("td:eq(4)").html('<input name="edit_price" value="'+price+'">');
		$(this).parents("tr").find("td:eq(5)").html('<input name="edit_disc" value="'+disc+'">');
		$(this).parents("tr").find("td:eq(6)").html('<input name="edit_catName" value="'+itemcatName+'">');

        $(this).parents("tr").find("td:eq(8)").prepend("<button class='btn btn-info btn-xs btn-update'>Update</button><button class='btn btn-warning btn-xs btn-cancel'>Cancel</button>")
		$(this).hide();
		
	});
	
	//updateButton in edit mode
    $("body").on("click", ".btn-update", function(){
		if (confirm("Are you sure you want to modify this item?"))
		var id=$(this).parents("tr").find("#deletebtn").attr("name");//gets the ID of the categorie from the Delete BUtton name using its #ID
			 id=id.substring(0);

			 var img = $(this).parents("tr").find("#uploadedImage").attr("name");
		switch (img){
			case undefined:
			var oldimg = $(this).parents("tr").find("#image").attr("name");
			var name = $(this).parents("tr").find("input[name='edit_name']").val();
			var desc = $(this).parents("tr").find("input[name='edit_desc']").val();
			var quant =$(this).parents("tr").find("input[name='edit_quant']").val();
			var price =$(this).parents("tr").find("input[name='edit_price']").val();
			var disc =$(this).parents("tr").find("input[name='edit_disc']").val();
			var itemcatName =$(this).parents("tr").find("input[name='edit_catName']").val();	
			updateItem(id,oldimg,name,desc,quant,price,disc,itemcatName);
			break;

			default:
				var name = $(this).parents("tr").find("input[name='edit_name']").val();
				var desc = $(this).parents("tr").find("input[name='edit_desc']").val();
				var quant =$(this).parents("tr").find("input[name='edit_quant']").val();
				var price =$(this).parents("tr").find("input[name='edit_price']").val();
				var disc =$(this).parents("tr").find("input[name='edit_disc']").val();
				var itemcatName =$(this).parents("tr").find("input[name='edit_catName']").val();
				updateItem(id,img,name,desc,quant,price,disc,itemcatName);
		}
        
		$(this).parents("tr").find("td:eq(8)").prepend("<button id='btn-edit' class='btn btn-primary editbtn'>Edit</button><button class='btn btn-warning btn-xs btn-cancel'>Cancel</button>")
		$(this).parents("tr").find(".btn-update").hide();
		$(this).parents("tr").find(".btn-cancel").hide();
		getItems();
		
	});
	function updateItem(itemID,itemImg,itemName,itemDesc,itemQuant,itemPrice,itemDisc,itemCatName) 
	{  
	$.ajax({
		type:'GET',
		url: "../utilities/ws_items.php",
		data:({op:3,id:itemID,img:itemImg,name:itemName,desc:itemDesc,quant:itemQuant,price:itemPrice,disc:itemDisc,itemCatName:itemCatName}),
  
		dataType:'json',
		timeout:5000,
		success: function(data, textStatus, xhr)
		{
		  if(data==-1){
			alert("Data Couldn't be Loaded");
		  }
		  else if (data==1){
			getitems();
		  }
		},
		error:function(xhr,status,errorThrown)
		{
		  alert(status + errorThrown);
		}
  
	});
	}

	//cancelButton in edit mode
	$("body").on("click", ".btn-cancel", function(){
		$(this).parents("tr").find("td:eq(8)").prepend("<button id='btn-edit' class='btn btn-primary editbtn'>Edit</button><button class='btn btn-warning btn-xs btn-cancel'>Cancel</button>")
		$(this).parents("tr").find(".btn-update").hide();
		$(this).parents("tr").find(".btn-cancel").hide();
		getItems();
		
	});
   
	
});