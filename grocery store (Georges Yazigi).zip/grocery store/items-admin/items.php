<head>
  <meta charset="utf-8">
  <title>Items</title>

  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=0">
  <!-- CSS -->
  <link rel="stylesheet" href="css/normalize.css">
  <link rel="stylesheet" href="../dist/jBox.all.css">
  <link rel="stylesheet" href="css/demo.css">
  <link rel="stylesheet" href="css/playground-avatars.css">
  <link rel="stylesheet" href="css/playground-inception.css">
  <link rel="stylesheet" href="css/playground-login.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/w3.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link href="css/datatables.min.css" rel="stylesheet">
  <link href="css/css?family=Roboto:400,500" rel="stylesheet">

  <script src="js/jquery-3.5.0.js"></script>


</head>

<body>
  <!-- NavBar -->
  <?php include 'navBar.php'; ?>
  <div class="container" style="overflow-x:auto;">
    <h2>Items</h2>
    <!-- Add Categorie -->
    <button id="additm" type="button"class="btn btn-info btn-lg" >Add Item</button>
    <br><br>


    <table id="" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
      <thead>
        <tr>
          <th class="th-sm">image</th>
          <th class="th-sm">name</th>
          <th class="th-sm">description</th>
          <th class="th-sm">quantity</th>
          <th class="th-sm">price</th>
          <th class="th-sm">discount</th>
          <th class="th-sm">categorie</th>
          <th class="Deleteth">Delete</th>
          <th class="Editth">Edit</th>
        </tr>
      </thead>
      <tbody id="myTable" class="Table tbody">

      </tbody>
    </table>
  </div>

  <!-- add item Modal -->
  <div style="display: none ;overflow-x:auto;" id="addItem">
  
      <table>
        <thead>
          <tr>
          <th><label for="image">Choose an image:</label></th>
          <th></th>
          <th>name</th>
          <th>description</th>
          <th>quantity</th>
          <th>price</th>
          <th>discount</th>
          <th>categorie</th>
          </tr>
        </thead>
        <tr>
          <th><input type="file" name="file" id="file" /><br/></th>
          <th><span id="uploaded_image"></span></th>
          <th><input name="name" value="" type="text" id="name" /></th>
          <th><input name="desc" value="" type="text" id="desc" /></th>
          <th><input name="quant" value="" type="text" id="quant" /></th>
          <th><input name="price" value="" type="text" id="price" /></th>
          <th><input name="disc" value="" type="text" id="disc" /></th>
          <th><input name="catName" value="" type="text" id="catName" /></th>

        </tr>
      </table>
      <button name="add" value="add" type="button" class="btn btn-default" id="add">Add</button>

</div>

  <!-- jquery-lib -->
  <script language="javascript" src="js/jquery.min.js"></script>
  <!-- Scripts -->
  <script type="text/javascript" src="js/datatables.min.js"></script>
  <script language="javascript" src="js/bootsrap.min.js"></script>

  <script src="../dist/jBox.all.js"></script>
  <script src="js/demo.js"></script>
  <script src="js/playground-avatars.js"></script>
  <script src="js/playground-inception.js"></script>
  <script src="js/playground-login.js"></script>

  <script language="javascript" src="js/items-admin.js"></script>

</body>

</html>