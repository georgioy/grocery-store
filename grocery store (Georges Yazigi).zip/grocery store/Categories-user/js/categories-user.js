$(document).ready(function(){

    getcategories();

	function getcategories() 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_categories.php",
      data:({op:0}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          populateCategories(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }
  function populateCategories(data)
  {
    if(data.length>0){
      $("#catTable").empty();
      $.each(data, function(index, row){
        var
         cat="<tr >";
		 cat+="<td id='tdimg'><b>"+row.cat_name+"<b><br><br><div style='text-align: center;'><img id='image' name='"+row.cat_img+"' height=75px width=100px src='../categories-admin/upload/"+row.cat_img+"'></div></td>"
         cat+="<td id='btnitems'><input type='image' name='"+row.cat_name+"' id='appendItems' src='img/next.png' alt='button' width='48' height='48'></td>"
         cat+="</tr>"
        $("#catTable").append(cat);
      });
    }
  }
  $("body").on("click","#appendItems", function(){// ">" Next ImageButton in categories table
  var catName = $(this).parents("tr").find("#appendItems").attr("name") ;
        $(this).parents("div").parents("div").parents("div").find("#catNameTh").html(catName);
        getItems(catName);
});



	function getItems(categorieName) 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_items.php",
      data:({op:4,itemCatName:categorieName}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          populateItems(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }

  function populateItems(data)
  {
    if(data.length>0){
      
      $("#itemsTable").empty();
      $.each(data, function(index, row){
          var x=row.item_price;
          var y=row.item_discount;
          var newPrice;
        var
         itm="<tr >";
         itm+="<td  id='tdimg' '><div style=' width: 200px; '><b>"+row.item_name+"<b><br><br></div><div style='text-align: center;'><img id='image' name='"+row.item_img+"' height=75px width=100px src='../items-admin/upload/"+row.item_img+"'></div></td>"
        
         if (y!=0 ) {
            newPrice = x - (x * y / 100);
            itm+="<td  id='tdprice' ><span style='color:#4CAF50; '><b>-</b>"+row.item_discount +"% "+"<br><span style='color:gray; text-decoration:line-through '>LBP "+ row.item_price+"</span><br> LBP "+newPrice+"</td>"
          }
          else
         itm+="<td id='tdprice' ><br><div style=' width: 100px; '><span >LBP "+ row.item_price+"</span></div></td>"
         itm+="<td id='btnitem'><input type='image' name='"+row.item_name+"' id='appendItem' src='img/next.png' alt='button' width='48' height='48'></td>"
		 itm+="</tr>"
        $("#itemsTable").append(itm);
      });
    }
  }

  $("body").on("click","#appendItem", function(){// ">" Next ImageButton in categories table
  var itemName = $(this).parents("tr").find("#appendItem").attr("name") ;
        $(this).parents("div").parents("div").parents("div").find("#itemNameTh").html(itemName);
        getItem(itemName);
});

function getItem(ItemName) 
  {  
  $.ajax({
      type:'GET',
      url: "../utilities/ws_items.php",
      data:({op:5,itemName:ItemName}),

      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
          data=JSON.parse(xhr.responseText);
          populateItem(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }

  });
  }

  function populateItem(data)
  {
    if(data.length>0){
      
      $("#itemTable").empty();
      $.each(data, function(index, row){
          var x=row.item_price;
          var y=row.item_discount;
          var newPrice;
        var
         
         itm="<tr>";
         itm+="<td  id='tdimg'><div id='itemName' name='"+row.item_name+"'></div><div style='text-align: center;'><img id='image' name='"+row.item_img+"' height=175px width=200px src='../items-admin/upload/"+row.item_img+"'></div></td>"
         itm+="</tr>"
         itm+="<tr>"
         if (y!=0 ) {
            newPrice = x - (x * y / 100);
            itm+="<td  id='tdprice'><div id='itmprice' name='"+ newPrice+"'></div><div style='max-width: 500px; margin: auto;'><br>Price: <span style='color:gray; text-decoration:line-through '>LBP "+ row.item_price+"</span><span style='color:#4CAF50; '> <b>-</b>"+row.item_discount +"%</span> <img height=35px src=img/right.png> "+" LBP "+newPrice+"</div></td>"
          }
          else
         itm+="<td id='tdprice'  ><div id='itmprice' name='"+ row.item_price+"'></div><div font-size='36px' style='max-width: 500px; margin: auto;'><br>Price: <span >LBP "+ row.item_price+"</span></div></td>"
         itm+="</tr>"
         itm+="<tr>"
         itm+="<td>"+row.item_desc+"</td>"
         itm+="</tr>"
         itm+="<tr>"
         itm+="<td>"
         itm+="<p class='plus-minus'><input type='image' src='img/minus.png' id='minus1' width='20' height='20' class='minus'/><input id='qty' type='text' value='1' style='width:50px;text-align:center;' class='qty'/><input type='image' id='add1' src='img/plus.png' width='20' height='20' class='add'/></p>"
         itm+="</td>"
         itm+="</tr>"
         itm+="<tr>"
         itm+="<td><p><input class='cart' id='addtoCart' type='button' value='Add to Cart'></input></p></td>"
         itm+="</tr>"
        $("#itemTable").append(itm);
      });
    }
  }
 
  $(function () {
    $("body").on("click",".add", function(){
        var $qty=$(this).closest('p').find('.qty');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal)) {
            $qty.val(currentVal + 1);
        }
    });
    $("body").on("click",".minus", function(){
        var $qty=$(this).closest('p').find('.qty');
        var currentVal = parseInt($qty.val());
        if (!isNaN(currentVal) && currentVal > 0) {
            $qty.val(currentVal - 1);
        }
    });
});
//get date
var d = new Date();

var month = d.getMonth()+1;
var day = d.getDate();

var output = d.getFullYear() + '/' +
    (month<10 ? '0' : '') + month + '/' +
    (day<10 ? '0' : '') + day;
var username = $("body").find("#uname").attr("name");
  getUnpaidorder(username,output);//if user has no open orders it creates a new one
//on add to cart click
$("body").on("click","#addtoCart", function(){
  
  //
  //getUname
  var username = $(this).parents("body").find("#uname").attr("name");
  getUnpaidOrderbyUname(username);

  
  // user now have an open 
  //order and it checks before it adds the item then it adds
  // it or update the quantity and total price if the user aleready
  // has this item in the basket
  
  //
  //call additemToBasket function that automatically add a new order
  // with the date and uname 
 
  
});
$("body").on("click","#addtoCart", function(){
    new jBox('Notice', {
    content: 'Added to Cart',
    color: 'black'
  });
});

function getUnpaidorder(uname,date) 
{  
$.ajax({
    type:'GET',
    url: "../utilities/ws_orders.php",
    data:({op:3,unm:uname}),

    dataType:'json',
    timeout:5000,
    success: function(data, textStatus, xhr)
    {
      data=JSON.parse(xhr.responseText);
      
       if(data==null) {
        createNewOrder(date,uname);
      }

      
    },
    error:function(xhr,status,errorThrown)
    {
      alert(status + errorThrown);
    }

});
}

  function createNewOrder(date,username) 
	{  
	$.ajax({
		type:'GET',
		url: "../utilities/ws_orders.php",
		data:({op:1,date:date,unm:username,stts:0}),
  
		dataType:'json',
		timeout:5000,
		success: function(data, textStatus, xhr)
		{
		  if(data==-1)
		  alert("data couldn't be loaded");
		  else{
			
        data=JSON.parse(xhr.responseText);
		 //   populateUsers(data);
		  }
		},
		error:function(xhr,status,errorThrown)
		{
		  alert(status + errorThrown);
		}
  
	});
  }
  
  function getUnpaidOrderbyUname(uname) 
  {  
    $.ajax({
      type:'GET',
      url: "../utilities/ws_orders.php",
      data:({op:3,unm:uname}),
    
      dataType:'json',
      timeout:5000,
      success: function(data, textStatus, xhr)
      {
        if(data==-1)
        alert("data couldn't be loaded");
        else{
        
          data=JSON.parse(xhr.responseText);
        
          populateUnpaidOrderID(data);
        }
      },
      error:function(xhr,status,errorThrown)
      {
        alert(status + errorThrown);
      }
    
    });
    }
    function populateUnpaidOrderID(data)
    {
      if(data.length>0){
        $("#orderIdDivTable").empty();
        $.each(data, function(index, row){
          var
           oID="<tr >";
           oID+="<td id='tdoID'><div id='orderID' name='"+row.order_ID+"'></div></td>"
           oID+="</tr>"
          $("#orderIdDivTable").append(oID);
        });
      }
      var orderID = $("body").find("#orderID").attr("name");
            var itemName = $("body").find("#itemName").attr("name");
      checkBeforeAddItem(orderID,itemName);
    
    }
    function  addItemsToOrderDetails(oID,iName,iQuant,iTtl)
    {
      $.ajax({
        type:'GET',
        url: "../utilities/ws_orderDetails.php",
        data:({op:1,oid:oID,pname:iName,pquant:iQuant,pttl:iTtl}),
      
        dataType:'json',
        timeout:5000,
        success: function(data, textStatus, xhr)
        {
          if(data==-1)
          alert("data couldn't be loaded");
          else{
          
            data=JSON.parse(xhr.responseText);
           
          //////
          }
        },
        error:function(xhr,status,errorThrown)
        {
          alert(status + errorThrown);
        }
      
      });
    }
    function checkBeforeAddItem(oID,iName)
    {
      $.ajax({
        type:'GET',
        url: "../utilities/ws_orderDetails.php",
        data:({op:4,oid:oID,pname:iName}),
      
        dataType:'json',
        timeout:5000,
        success: function(data, textStatus, xhr)
        {
           data=JSON.parse(xhr.responseText);
          
          if(data==null) {
            var orderID = $("body").find("#orderID").attr("name");
            var itemName = $("body").find("#itemName").attr("name");
            var itemQuant = $("body").find("#qty").val();
            var itemprice = $("body").find("#itmprice").attr("name");
            var ttl=itemQuant*itemprice;
      
            addItemsToOrderDetails(orderID,itemName,itemQuant,ttl);
          }
          else{
           
            populateItemIfAvailable(data);
          }
          
        },
        error:function(xhr,status,errorThrown)
        {
          alert(status + errorThrown);
        }
      
      });
    }
    function populateItemIfAvailable(data)
    {
      if(data.length>0){
        $("#AvailableItemDivTable").empty();
        $.each(data, function(index, row){
          var
           IIA="<tr >";
           IIA+="<td id='tdIIA'><div id='orderDetailsID' name='"+row.order_Details_ID+"'></div></td>"
           IIA+="<td id='tdIIA'><div id='order_ID' name='"+row.order_ID+"'></div></td>"
           IIA+="<td id='tdIIA'><div id='order_Product_Name' name='"+row.order_Product_Name+"'></div></td>"
           IIA+="<td id='tdIIA'><div id='order_Product_Quantity' name='"+row.order_Product_Quantity+"'></div></td>"
           IIA+="<td id='tdIIA'><div id='order_Total_Price' name='"+row.order_Total_Price+"'></div></td>"

           IIA+="</tr>"
          $("#AvailableItemDivTable").append(IIA);
        });
      }
      var orderID = $("body").find("#orderID").attr("name");
      var itemName = $("body").find("#itemName").attr("name");
      var itemQuant = $("body").find("#qty").val();
      var itemprice = $("body").find("#itmprice").attr("name");
      var ttl=itemQuant*itemprice;

      var orderDetailsID = $("body").find("#orderDetailsID").attr("name");
      var itemQuantOld = $("body").find("#order_Product_Quantity").attr("name");
      var itemttlpriceOld = $("body").find("#order_Total_Price").attr("name");
      var quantTtl=parseInt(itemQuant)+parseInt(itemQuantOld);
      var newTtl=parseInt(ttl)+parseInt(itemttlpriceOld);
      UpdateItemToOrderDetails(orderDetailsID,orderID,itemName,quantTtl,newTtl.toString());
    
    }

    function UpdateItemToOrderDetails(oDId,oID,iName,iQuant,iTtl)
    {
      $.ajax({
        type:'GET',
        url: "../utilities/ws_orderDetails.php",
        data:({op:2,id:oDId,oid:oID,pname:iName,pquant:iQuant,pttl:iTtl}),
      
        dataType:'json',
        timeout:5000,
        success: function(data, textStatus, xhr)
        {
          if(data==-1)
          alert("data couldn't be loaded");
          else{
          
            data=JSON.parse(xhr.responseText);
           
          }
        },
        error:function(xhr,status,errorThrown)
        {
          alert(status + errorThrown);
        }
      
      });
    }

    
    // getorderDetailsGrandTotal(orderID);

    // function  getorderDetailsGrandTotal(oID)
    // {
    //   $.ajax({
    //     type:'GET',
    //     url: "../utilities/ws_orderDetails.php",
    //     data:({op:3,oid:oID}),
      
    //     dataType:'json',
    //     timeout:5000,
    //     success: function(data, textStatus, xhr)
    //     {
    //       if(data==-1)
    //       alert("data couldn't be loaded");
    //       else{
          
    //         data=JSON.parse(xhr.responseText);
    //         populateGrandToTal(data);
    //       //////
    //       }
    //     },
    //     error:function(xhr,status,errorThrown)
    //     {
    //       alert(status + errorThrown);
    //     }
      
    //   });
    // }
    // var globalTotal=0;
    // function populateGrandToTal(data)
    // {
    //   if(data.length>0){
    //     $("#orderGrandPriceTable").empty();
    //     $.each(data, function(index, row){
    //       var Gttl=row.GLOBAL_ORDER_SUM;
    //       if(Gttl==null){
    //         Gttl=0;
    //         var
    //        oID="<tr >";
    //        oID+="<td  id='tdoID'><div class='grandTotal' name='"+Gttl+"'></div><i class='fa fa-shopping-cart' aria-hidden='true' style='font-size:28px;color:#4CAF50'></i><b style='font-size:24px;'> TOTAL PRICE: LBP "+Gttl+"</b></td>"
    //        oID+="</tr>"
    //       $("#orderGrandPriceTable").append(oID);
    //       }
    //       else{
    //         Gttl=row.GLOBAL_ORDER_SUM;
    //         var
    //        oID="<tr >";
    //        oID+="<td  id='tdoID'><div class='grandTotal' name='"+Gttl+"'></div><i class='fa fa-shopping-cart' aria-hidden='true' style='font-size:28px;color:#4CAF50'></i><b style='font-size:24px;'> TOTAL PRICE: LBP "+Gttl+"</b></td>"
    //        oID+="</tr>"
    //       $("#orderGrandPriceTable").append(oID);
    //       }
          
    //     });
    //   }
    //   globalTotal= $("body").find(".grandTotal").attr("name");//jbox on hover checkout btn
    //   new jBox('Mouse', {
    //     attach: '.basketbtn',
    //     position: {
    //       x: 'right',
    //       y: 'bottom'
    //     },
        
    //     content: '<b style="color:#4CAF50;"><i class="fa fa-check" style="font-size:28px;" aria-hidden="true"></i> PAY <p style="font-size:28px;color:#4CAF50">'+globalTotal+'</p> LBP</b>'
    //   });
      
    // }
});