$(document).ready(function()
{
     $('.message a').click(function(){
                     $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
                 });
 
     $("#but_submit").click(function(){   
         
        
          username = $("#username").val();
          password = $("#password").val();	

          getlogin(username,password);
     });
    
     $("#txt_username").keyup(function(){
        val = $(this).val().trim();
        checkUser(val);
    });
     $("#txt_email").keyup(function(){
         value = $(this).val().trim();
        
         checkEmail(value);
      });
      $("#txt_Password").keyup(function(){
        value = $(this).val().trim();
        password = $("#txt_Password").val();
        password2 =$("#txt_Password2").val();	
        validatePasswordsMatch(password,password2);
     });
      $("#txt_Password2").keyup(function(){
        value = $(this).val().trim();
        password = $("#txt_Password").val();
        password2 =$("#txt_Password2").val();	
        validatePasswordsMatch(password,password2);
     });
     
      $("#reg_btn").click(function(){   
        
        username = $("#txt_username").val();
        
        email = $("#txt_email").val();
        password = $("#txt_Password").val();
        password2=$("#txt_Password2").val();
        type=0;
        if(password == password2){
                if(password.length >= 6 ){
                addUser(email,username,password,type)
                }
                else{
                    
                    alert( "you have to enter at least 6 digits password!");
                     }
        }else{
            alert( "Passwords Don't Match");
        }

      });



        function addUser(userEmail,username,password,userType) 
	    {  
    	$.ajax({
		type:'GET',
		url: "../utilities/ws_users.php",
		data:({op:4,email:userEmail,uname:username,pwd:password,type:userType}),
  
		dataType:'json',
		timeout:5000,
		success: function(data, textStatus, xhr)
		{
		  if(data==-1)
		  alert("data couldn't be loaded");
		  else{
			if(data=="User already exists")
			alert("User already exists");
			else{
                getlogin(username,password);
			}
		  //  data=JSON.parse(xhr.responseText);
		 //   populateUsers(data);
		  }
		},
		error:function(xhr,status,errorThrown)
		{
		  alert(status + errorThrown);
		}
  
	});
	}

       function validatePasswordsMatch(pwd1,pwd2)
     {
        if(pwd1 == ""||pwd2 == ""){

        return $("#password_response").html("");  
     }else if (pwd1==pwd2){
             response = '<span style="color: green;">Passwords Match</span>';
             return $('#password_response').html(response);
         }else if(pwd1 != ""||pwd2 != "")
           {return $("#password_response").html("");  
            
         }else if(pwd1!=pwd2 ) {
            return $("#password_response").html(""); 
         }
        
     }
       function getlogin(nm,pwd)
       {			
           	 
        $.ajax({
            type: 'GET',
            url: "../utilities/ws_users.php",
            data: ({op:1,uname:nm,upwd:pwd}),
            
            dataType: 'json',
            timeout: 5000,
            success: function(data, type, xhr) 
            {		
                data = JSON.parse(xhr.responseText);	 
                 		  						  				  
                 if(data==-1){
                 alert("Wrong credentials");
                    } else if(data==0){
                    window.location.href="../HomePage-user/Home-PageUser.php";
                    } else if(data==1){
                     window.location.href="../HomePage/Home-Page.php"; 	
                             
                 }
                
            },
            error: function(xhr, status, errorThrown) 
            {
                            
                 alert(status + errorThrown);				  
            }
        });  
   
       }
       
      function checkUser(value){	
               
         if(value != "")
         {
             
           $.ajax({
              
                     type: 'GET',
                     url: "../utilities/ws_users.php",
                     data: ({op:6,uname:value}),
                     
                     dataType: 'json',
                     timeout: 5000,
                 success: function(data, textStatus, xhr) 
                 {			
                             if(data==-1){
                                 alert("data could Not Be Loaded!");
                             }			  				  
                             else
                             data = JSON.parse(xhr.responseText);	  	
                                 validateUname(data);					
                                 
                             
                 },
                     error: function(xhr, status, errorThrown) 
                     {  
                          alert(status + errorThrown);				  
                     }
              });
         }else
             $("#uname_response").html("");  
     }
     function validateUname(data)
     {
         if (data==1){
            
             return  $("#uname_response").html("");  
           
         }else if (data==0){
            response = '<span style="color: red;">username already taken</span>';
            return $('#uname_response').html(response);
         } 
     }



     function checkEmail(value){	
               
        if(value != "")
        {
            
          $.ajax({
             
                    type: 'GET',
                    url: "../utilities/ws_users.php",
                    data: ({op:7,email:value}),
                    
                    dataType: 'json',
                    timeout: 5000,
                success: function(data, textStatus, xhr) 
                {			
                            if(data==-1){
                                alert("data could Not Be Loaded!");
                            }			  				  
                            else
                            data = JSON.parse(xhr.responseText);	  	
                                validateEmail(data);					
                                
                            
                },
                    error: function(xhr, status, errorThrown) 
                    {  
                         alert(status + errorThrown);				  
                    }
             });
        }else
            $("#email_response").html("");  
    }
    function validateEmail(data)
    {
        if (data==1){
            
            return  $("#email_response").html("");  
          
        }else if (data==0){
           response = '<span style="color: red;">email already used</span>';
           return $('#email_response').html(response);
        } 
    }
 
     
   });